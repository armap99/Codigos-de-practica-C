#include<stdio.h>
#include<conio.h>
main()
{
	int men;
	float med,re;
	printf("MENU\n");
	printf("1. Para convertir de pulgadas a milimetros\n2. Para convertir de yardas a metros.\n3. Para convertir de millas a kilometros\n");
	scanf("%i",&men);
	switch(men)
	{
		case 1:
			printf("Intruduzca la cantidad de pulgadas a transformar: ");
			scanf("%f",&med);
			re=med*25.45;
			printf("%.2f son %.2f milimetros",med,re);
		break;
		case 2:
			printf("Intruduzca la cantidad de yardas a transformar: ");
			scanf("%f",&med);
			re=med*0.9144;
			printf("%.2f son %.2f metros",med,re);
		break;
		case 3:
			printf("Intruduzca la cantidad de millas a transformar: ");
			scanf("%f",&med);
			re=med*1.6093;
			printf("%.2f son %.2f kilometros",med,re);
		break;
		default:
			printf("ERROR");
	}
	getch();
}
