/*Nombre:Luis Armando Prado N��ez 
  Programa:Estructuras de empelados
  Fecha:24/10/18
  D.P:Se pediran los nombres de un empleado y se guardaran en una estrsuctura y despues los mostrara todos en pantalla*/
  
#include<stdio.h>
#include <conio.h>
#define p printf
#define s scanf

main(){
	char rep;
	struct{
		char nom[50];
		int hrT;
		float sb, imp, tp, ch;
	}empleado;
	
	do{
		p("Nombre del empleado: ");
		fflush(stdin);
		gets(empleado.nom);
		p("\nHoras trabajadas de %s: ",empleado.nom);
		s("%i",& empleado.hrT);
		p("\nCosto de hora trabajada de %s: ",empleado.nom);
		s("%f",&empleado.ch);
		empleado.sb = empleado.hrT * empleado.ch;
		empleado.imp = empleado.sb * .16;
		empleado.tp = empleado.sb - empleado.imp;
		p("\nNombre del empelado: %s ",empleado.nom);
		p("\nHoras trabajadas: %i",empleado.hrT);
		p("\nCosto de hora: $ %.2f",empleado.ch);
		p("\nSueldo base: $ %.2f",empleado.sb);
		p("\nImpuesto: %.2f",empleado.imp);
		p("\nTotal a pagar: %.2f",empleado.tp);
		p("\nDeseas volver a corre el programa?\nS=si\nN=no");
		fflush(stdin);
		s("%c",&rep);
	}while(rep=='S' || rep=='s');
}
