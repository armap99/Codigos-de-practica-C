/*Nombre:Luis Armando Prado N��ez
  Programa:Triangulo de numeros do-while
  21/09/18
  D.P:Mostrar en pantalla los numeros deseados en forma decentente y acendente*/

#include<stdio.h>
#include<conio.h>
main()
{
	int n,j,i,a;
	char rep;
	do{
		a=1;
		i=1;
		printf("Hasta que numero quiere realizar la figura: ");
		scanf("%i",&n);	
		do{
			printf("\n");
			a=1;
			j=1;
			do{
				printf("%i ",a );
				a++;
				j++;	
			}
			while(j<=i);
			i++;
		}
		while(i<=n);
		i=1;
		do{
			printf("\n");
			a=1;
			j=n;
			do{
				printf("%i ",a );
				a++;
				j--;
			}
			while(j>=i);
			i++;
		}
		while(i<=n);
		printf("Desea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
	}
	while(rep=='S'||rep=='s');
}
