/*Nombre:Luis Armando Prado N��ez
  Programa:Suma de datos de una matriz menu 
  03/10/18
  D.P:Mostrara la matriz introducuda y la suma de sus elementos */
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#define t 10
main()
{
	int i,j,matriz[t][t],fc,sumd;
	char rep,men;
	do{
		printf("Menu de bucles\n");
		printf("F-Suma de todos los elementos For\nW-Suma de todos los elementos con While\nD-Suma de todos los elementos con Do while\n");
		fflush(stdin);scanf("%c",&men);
		switch(men)
		{
			case'f':case'F':
				printf("Cuantas filas y columnas quieres max 10 ");
		        scanf("%i",&fc);
		        for(i=0;i<fc;i++)
		        {
		            for(j=0;j<fc;j++)
		            {
		                printf("Teclea el elemento de la matriz [%i][%i] ",i,j);
		                scanf("%i",&matriz[i][j]);
		            }
		        }
		        for(i=0;i<fc;i++)
		        {
		            printf("\n");
		            for(j=0;j<fc;j++)
		                printf("%i ",matriz[i][j]);
		        }
		        for(i=0;i<fc;i++)
		        {
		        	for(j=0;j<fc;j++)
		        	{
		        		sumd+=matriz[i][j];
					}
				}
				printf("\nLa suma de todos los datos es %i",sumd);
			break;
			case'w':case'W':
				printf("Cuantas filas y columnas quieres max 10 ");
		        scanf("%i",&fc);
		        i=0;
		        while(i<fc)
		        {
		        	j=0;
		            while(j<fc)
		            {
		                printf("Teclea el elemento de la matriz [%i][%i] ",i,j);
		                scanf("%i",&matriz[i][j]);
		                j++;
		            }
		            i++;
		        }
		        i=0;
		        while(i<fc)
		        {
		        	j=0;
		            printf("\n");
		            while(j<fc)
		            {
		                printf("%i ",matriz[i][j]);
		                j++;
		        	}
		            i++;
		        }
		        i=0;
		        while(i<fc)
		        {
		        	j=0;
		        	while(j<fc)
		        	{
		        		sumd+=matriz[i][j];
		        		j++;
					}
					i++;
				}
				printf("\nLa suma de todos los datos es %i",sumd);
			break;
			case'd':case'D':
				printf("Cuantas filas y columnas quieres max 10 ");
		        scanf("%i",&fc);
		        i=0;
		        do{
		        	j=0;
		            do{
		                printf("Teclea el elemento de la matriz [%i][%i] ",i,j);
		                scanf("%i",&matriz[i][j]);
		                j++;
		            }
		            while(j<fc);
		            i++;
		        }
		        while(i<fc);
		        i=0;
		        do{
		        	j=0;
		            printf("\n");
		            do{
		                printf("%i ",matriz[i][j]);
		                j++;
		        	}
		        	while(j<fc);
		            i++;
		        }
		        while(i<fc);
		        i=0;
		        do{
		        	j=0;
		        	do{
		        		sumd+=matriz[i][j];
		        		j++;
					}
					while(j<fc);
					i++;
				}
				while(i<fc);
				printf("\nLa suma de todos los datos es %i",sumd);
			break;
		}
		printf("Desea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
		system("cls");
	}
	while(rep=='S'||rep=='s');
}
