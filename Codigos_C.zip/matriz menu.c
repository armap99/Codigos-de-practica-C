/*Nombre:Luis Armando Prado N��ez
  Programa:Matriz menu
  03/10/18
  D.P:Se introduciran los datos que quieran que se muestren en pantalla*/
#include<stdlib.h>
#include<conio.h>
#define t 10
main()
{
	int i,j,matriz[t][t],fc,rep;
	char men;
	do{
		printf("Menu de bucles\n");
		printf("F-Mariz For\nW-Matriz While\nD-Matriz Do while\n");
		/*fflush(stdin);*/scanf("%c",&men);
		switch(men)
		{
			case'f':case'F':
				printf("Cuantas filas y columnas quieres max 10 ");
		        scanf("%i",&fc);
		        for(i=0;i<fc;i++)
		        {
		            for(j=0;j<fc;j++)
		            {
		                printf("Teclea el elemento de la matriz [%i][%i] ",i,j);
		                scanf("%i",&matriz[i][j]);
		            }
		        }
		        for(i=0;i<fc;i++)
		        {
		            printf("\n");
		            for(j=0;j<fc;j++)
		                printf("%i ",matriz[i][j]);
		        }
			break;
			case'w':case'W':
				printf("Cuantas filas y columnas quieres max 10 ");
		        scanf("%i",&fc);
		        i=0;
		        while(i<fc)
		        {
		        	j=0;
		            while(j<fc)
		            {
		                printf("Teclea el elemento de la matriz [%i][%i] ",i,j);
		                scanf("%i",&matriz[i][j]);
		                j++;
		            }
		            i++;
		        }
		        i=0;
		        while(i<fc)
		        {
		            printf("\n");
		            j=0;
		            while(j<fc)
		            {
		            	printf("%i ",matriz[i][j]);
		            	j++;
					}
					i++;
		        }
			break;
			case'd':case'D':
				printf("Cuantas filas y columnas quieres max 10 ");
		        scanf("%i",&fc);
		        i=0;
		        do{
		        	j=0;
		            do{
		                printf("Teclea el elemento de la matriz [%i][%i] ",i,j);
		                scanf("%i",&matriz[i][j]);
		                j++;
		            }
		            while(j<fc);
		            i++;
		        }
		        while(i<fc);
		        i=0;
		        do{
		            printf("\n");
		            j=0;
		            do{
		            	printf("%i ",matriz[i][j]);
		            	j++;
					}
					while(j<fc);
					i++;
		        }
		        while(i<fc);
			break;
		}
		printf("\nDeseas repetir el programa? 1=si ");
        scanf("%i",&rep);
	}
	while(rep==1);
	
    getch();
}
