/*Nombre:Luis Armando Prado N��ez
  Programa:Funcion no figo
  10/10/18
  D.P:Una fincion que sera la no sucesion de fibonacci*/
  
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

void figo()
{
	int x0,x1,n,aux,i,suma;
	printf("Hasta que numero quiere llegar: ");
	scanf("%i",&n);
	suma=0;
	x1=1;
	while(x1<=n){
		aux=x0;
		x0=x1;
		x1+=aux;
		i=x0+1;
		while(i<x1 && i<=n){
			suma+=i;
			printf("%d, ",i);
			i++;
		}
	}
	printf("\nLa suma es: %i",suma);
}
main()
{
	int rep;
	do{
		figo();
		printf("\nDesea repetir el test: 1-SI");
		scanf("%i",&rep);
		system("cls");
		getch();
	}
	while(rep==1);
}
