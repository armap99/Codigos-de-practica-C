/*Nombre:Luis Armando Prado N��ez
 Proyecto:Menu de ejecercicios
 31/08/18
 DP:Contiene un menu con los ejercicios de estructura secuencial y los de estructura selectiva*/
 
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<math.h>
#define pi 3.1416
main()
{
	char men1,men2,men3;
	int co,ca,hor,N,N2,l1,l2,l3,n1,n2,pa,con,bo,don,cuer,sem,di,hr,min,seg,mint;
	float h,r,a,iva,total,cost,sueld,tot,km,ba,hl,ar,totalp,totd,tf,pat,cont,bot,dont,cuert;
	char dep[50],pues[50],nom[50],des[50],nom2[50];
	long int total2,semt,dit,hrt,totalc;
	printf("MENU: \n");
	printf("S s=Ejercicos de estructura secuencial \nI i=Ejercicios de estructura selectiva ");
	fflush(stdin);scanf("%c",&men1);
	system("cls");
	switch(men1)
	{
		case'S':case's':printf("Menu de esctructura secuencial \n");
			printf("P p-Hipotenusa del triangulo \nS s-Area de un circulo \nT t=Sueldo a pagar \nC c=Boleto de transporte\n	Q q=Area de un triangulo");
			fflush(stdin);scanf("%c",&men2);
					switch (men2)
						{
							case'P':case'p':
								printf("Cuanto miden los catetos del triangulo en cm ");
								scanf("%i%i",&ca,&co);
								h=sqrt(ca*ca+pow(co,2));
								printf("La hipotenusa del triangulo es= %.2f cm ",h);
							break;
							case'S':case's':
								printf("Introduce el valor del radio: ");
								scanf("%f",&r);
								a=(pi*pow(r,2));
								printf("El area del circulo es %.2f",a);
							break;
							case'T':case't':
								printf("Introdusca su nombre: ");
								fflush(stdin),gets(nom);
								printf("Introduzca el puesto que desempe�a: ");
								fflush(stdin),gets(pues);
								printf("Introduzca el departamento en el que trabaja: ");
								fflush(stdin),gets(dep);
								printf("Introdusca las horas trabajadas: ");
								scanf("%i",&hor);
								printf("Introdusca costo de hora: ");
								scanf("%f",&cost);
								sueld=hor*cost;
								iva=sueld*.16;
								total=sueld-iva;
								system("cls");
								puts("CUCEI");
								printf("Nombres: ");puts(nom);
								printf("Departamento: ");puts(dep);
								printf("Horas trabajadas: %i \n",hor);
								printf("Costo de hora: %.2f \n",cost);
								printf("Sueldo: %.2f \n",sueld);
								printf("IVA: %.2f \n",iva);
								printf("Total a pagar: %.2f \n",total);	
							break;
							case'C':case'c':
								printf("Introdusca su nombre: ");
								fflush(stdin),gets(nom2);
								printf("Introdusca el destino deseado: ");
								fflush(stdin),gets(des);
								printf("Introdusca kilometros a recorrer: ");
								scanf("%f",&km);
								tot=km*11.75;
								puts("Autobuses CUCEI");
								printf("Pasajero: ");puts(nom2);
								printf("Destino: ");puts(des);
								printf("Kilometros a recorrer: %.2f \n",km);
								printf("Total a pagar: %.2f ",tot);
							break;
							case'Q':case'q':
								printf("Introduce la altura del triangulo: ");
								scanf("%f",&hl);
								printf("Introduce la base del triangulo: ");
								scanf("%f",&ba);
								ar=ba*hl/2;
								printf("El area del triangulo es: %.2f",ar);
							break;	
						}
		break;
		case'I':case'i':printf("Menu de estructura selectiva \n");
			printf("P p-Par o impar \nS s-Negativo o positivo \nT t-Tipo de triangulo \nC c-Costo por segundos trabajados \nQ q-Mayor o menor \nX x:Panaderia");
			fflush(stdin);scanf("%c",&men3);
			switch(men3)
			{
				case'P':case'p':
					printf("Teclea un numero entero: ");
					scanf("%d",&N);
					if(N%2==0)
						printf("%d es par \n ",N);
					if(N%2!=0)
						printf("%d es impar \n",N);
				break;
				case'S':case's':
					printf("Introduzca un nuemro entero: ");
					scanf("%i",&N2);
					if(N2>0)
						printf("%i es positivo \n",N2);
					if(N2<0)
						printf("%i es negativo \n",N2);
					if(N2==0)
						printf("%i es cero \n",N2);
				break;
				case'T':case't':
					printf("Introduzca el primer lado del triangulo: ");
					scanf("%i",&l1);
					printf("Introduzca el segundo lado del triangulo: ");
					scanf("%i",&l2);
					printf("Introduzca el tercer lado del triangulo: ");
					scanf("%i",&l3);
					if(l1==l2&&l1==l3&&l2==l3)
						printf("El triangulo es equilatero \n");
					if(l1==l2&&l3!=l1||l2==l3&&l2!=l1||l3==l1&&l3!=l2)
						printf("El triangulo es isoseles \n");
					if(l1!=l2&&l1!=l3&&l3!=l2)
						printf("El triangulo es escaleno");
				break;
				case'C':case'c':
					printf("Introduzca las semanas trabajadas: ");
					scanf("%d",&sem);
					printf("Introduzca los dias trabajados: ");
					scanf("%d",&di);
					printf("Introduzca las horas trabajadas: ");
					scanf("%d",&hr);
					printf("Introduzca los minutos trabajados: ");
					scanf("%d",&min);
					printf("Introduzca los segundos trabajados: ");
					scanf("%d",&seg);
					semt=sem*604800;
					dit=di*86400;
					hrt=hr*3600;
					mint=min*60;
					total2=semt+dit+hrt+mint+seg;
					if(total2>100000)
						totalc=total2*.25;
					if(total2<=100000)
						totalc=total2*.50;
					system("cls");
					printf("El costo del preoceso es: %i",totalc);	
				break;	
				case 'Q':case'q':
					printf("Introduzca el primer numero entero: ");
					scanf("%d",&n1);
					printf("Introduzca el segundo numero entero: ");
					scanf("%d",&n2);
					if(n1>n2)
						printf("%d es mayor que %d",n1,n2);
					if(n1<n2)
						printf("%d es menor que %d",n1,n2);	
					if(n1==n2)
						printf("%d son iguales %d",n1,n2);
				break;
				case'X':case'x':
					printf("Cuantas donas: ");
					scanf("%i",&don);
					printf("Cuantas rebanadas de pastel: ");
					scanf("%i",&pa);
					printf("Cuantas conchas: ");
					scanf("%i",&con);
					printf("Cuantos bolillos: ");
					scanf("%i",&bo);
					printf("Cuantos cuernitos: ");
					scanf("%i",&cuer);
					dont=don*12;
					pat=pa*25;
					cont=con*5;
					bot=bo*8;
					cuert=cuer*7;
					total=dont+pat+cont+bot+cuert;
					system("cls");
					printf("Cantidad Descripcion Precio Total \n");
					printf("  %i        Dona        12   %.2f \n",don,dont);
					printf("  %i       Pastel       25   %.2f \n",pa,pat);
					printf("  %i       Concha       05   %.2f \n",con,cont);
					printf("  %i       Bolillo      08   %.2f \n",bo,bot);
				    printf("  %i       Cuernito     07   %.2f \n",cuer,cuert);
					if(total<100||total==100)	
						printf("Total: %.2f \n",total);
					if(total>100)
					{
						totd=total*.15;
						tf=total-totd;
						printf("Total: %.2f \n",total);
						printf("Total con descuento: %.2f \n",tf);
					}
				break;
			}
		break;
	}
	getch();
}
