/*Nombre:Luis Armando Prado N��ez
  Programa:Suma de diagonales de una matriz menu
  06/10/18
  D.P:Mostrara la suma de las diagonales de la matriz y sus elementos sobrantes */
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#define t 10
main()
{
	int i,j,matriz[t][t],fc,sumdp,sumds,smas;
	char rep,men;
	do{
		printf("Menu de bucles\n");
		printf("F-Sumar diagonales con For\nW-Sumar diagonales con con While\nD-Sumar diagonales con con Do while\n");
		fflush(stdin);scanf("%c",&men);
		switch(men)
		{
			case'f':case'F':
				printf("Cuantas filas y columnas quieres max 10 ");
			    scanf("%i",&fc);
			    for(i=0;i<fc;i++)
			    {
			        for(j=0;j<fc;j++)
			        {
			            printf("Teclea el elemento de la matriz [%i][%i] ",i,j);
			            scanf("%i",&matriz[i][j]);
			            if(i==j)
						{
							sumdp+=matriz[i][j];
							if(i+j+1==fc)
								sumds+=matriz[i][j];
						}
						else if (i+j+1==fc)
							sumds+=matriz[i][j];
						else
							smas+=matriz[i][j];
			        }
			    }
			    for(i=0;i<fc;i++)
			    {
			        printf("\n");
			        for(j=0;j<fc;j++)
			            printf("%i ",matriz[i][j]);
			    }
			    printf("\nDiagonal principal: %i",sumdp);
				printf("\nDiagnoal invertida: %i",sumds);
				printf("\nResto de elementos: %i",smas);
			break;
			case'w':case'W':
				printf("Cuantas filas y columnas quieres max 10 ");
			    scanf("%i",&fc);
			    i=0;
			    while(i<fc)
			    {
			    	j=0;
			        while(j<fc)
			        {
			            printf("Teclea el elemento de la matriz [%i][%i] ",i,j);
			            scanf("%i",&matriz[i][j]);
			            if(i==j)
						{
							sumdp+=matriz[i][j];
							if(i+j+1==fc)
								sumds+=matriz[i][j];
						}
						else if (i+j+1==fc)
							sumds+=matriz[i][j];
						else
							smas+=matriz[i][j];
						j++;
			        }
			        i++;
			    }
			    i=0;
			    while(i<fc)
			    {
			    	j=0;
			        printf("\n");
			        while(j<fc)
			            {
			            	printf("%i ",matriz[i][j]);
			            	j++;
						}
			        i++;
			    }
			    printf("\nDiagonal principal: %i",sumdp);
				printf("\nDiagnoal invertida: %i",sumds);
				printf("\nResto de elementos: %i",smas);
			break;
			case'd':case'D':
				printf("Cuantas filas y columnas quieres max 10 ");
			    scanf("%i",&fc);
			    i=0;
			    do{
			    	j=0;
			        do{
			            printf("Teclea el elemento de la matriz [%i][%i] ",i,j);
			            scanf("%i",&matriz[i][j]);
			            if(i==j)
						{
							sumdp+=matriz[i][j];
							if(i+j+1==fc)
								sumds+=matriz[i][j];
						}
						else if (i+j+1==fc)
							sumds+=matriz[i][j];
						else
							smas+=matriz[i][j];
						j++;
			        }
			        while(j<fc);
			        i++;
			    }
			    while(i<fc);
			    i=0;
			    do{
			    	j=0;
			        printf("\n");
			            do{
			            	printf("%i ",matriz[i][j]);
			            	j++;
						}
						while(j<fc);
			        i++;
			    }
			    while(i<fc);
			    printf("\nDiagonal principal: %i",sumdp);
				printf("\nDiagnoal invertida: %i",sumds);
				printf("\nResto de elementos: %i",smas);
			break;
		}
		printf("\nDesea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
		system("cls");
	}
	while(rep=='S'||rep=='s');
}
