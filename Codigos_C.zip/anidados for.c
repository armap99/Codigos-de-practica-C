/*Nombre:Luis Armando Prado N��ez
  Programa:Ciclos anidados for
  21/09/18
  D.P:dos for anidados para mostrar tres holas 4 veces */
  
#include<stdio.h>
#include<conio.h>
main()
{
	int i,j;
	for(i=1;i<=4;i++)
	{
		printf("\n");
		for(j=1;j<=3;j++)
		printf( " Hola ");
	}
	getch();
}
