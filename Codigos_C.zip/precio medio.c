#include<stdio.h>
#include<stdlib.h>
int main()
{
	float pre1,pre2,pre3,med;
	printf("Introduzca el precio del producto en el establecimiento numero 1, en euros: ");
	scanf("%f",&pre1);
	printf("Introduzca el precio del producto en el establecimiento numero 2, en euros: ");
	scanf("%f",&pre2);
	printf("Introduzca el precio del producto en el establecimiento numero 3, en euros: ");
	scanf("%f",&pre3);
	med=(pre1+pre2+pre3)/3;
	printf("La media del precio del producto es: %.2f ",med);
	return 0;
}
