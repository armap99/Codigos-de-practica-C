/*Nombre:Luis Armando Prado N��ez
  Programa:Operaciones basicas con funciones con paso de parametro y sin retorno
  17/10/18
  D.P:Mostrara en pantalla un menu de operaciones basicas que se realizaran las operaciones */
  
  #include<stdio.h>
  #include<stdlib.h>
  #include<conio.h>
  #include<math.h>
  int a,b;
  void suma(int,int);
  void resta(int,int);
  void multiplicacion(int,int);
  void division(int,int);
  void residuo(int,int);
  void potencia(int,int);
  void raiz(int);

main()
{
	int op,opc;
	do{
		printf("Este programa realiza las operaciones basicas\n �Cual desea realizar?\n");
		printf("1-Suma\n2-Resta\n3-Multiplicacion\n4-Division\n5-Residuo\n6-Potencia\n7-Raiz\n");
		scanf("%i",&op);
		printf("Teclea 2 numeros enteros: \n");
		scanf("%i %i",&a,&b);
		switch(op) 
		{
			case 1:printf("Suma de %i + %i ",a,b);suma(a,b);break;
			case 2:printf("Resta de %i - %i ",a,b);resta(a,b);break;
			case 4:printf("Division de %i / %i ",a,b);division(a,b);break;
			case 5:printf("Residuo de %i % %i ",a,b);residuo(a,b);break;
			case 6:printf("Potencia de %i ^ %i ",a,b);potencia(a,b);break;
			case 7:printf("Raiz de %i ",a);raiz(a);break;
			default:
				printf("ERROR");
		}
		printf("\nDesea repetir el programa 1-Si\n");
		scanf("%i",&opc);
	}
	while(opc==1);
}

void suma(int x, int y)
  {
  	printf("= %i",x+y);
  }

void resta(int q, int s)
  {
  	printf("= %i",q-s);
  }

void multiplicacion(int a, int b)
  {
  	printf("= %i",a*b);	
  }
  
  void division(int w, int x)
  {
  	printf("= %i",w/x);
  }

void residuo(int x, int y)
  {
  	printf("= %i",x%y);
  }
  
  void potencia(int z, int y)
  {
  	printf("= %i",pow(z,y));
  }

void raiz(int x)
  {
  	printf("= %.0f",sqrt(x));
  }  
