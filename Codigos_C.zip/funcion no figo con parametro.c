/*Nombre:Luis Armando Prado N��ez
  Programa:Funcion no figo con parametro y sin retorno
  17/10/18
  D.P:Una fincion que sera la no sucesion de fibonacci*/
  
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
int n;
void figo(int n)
{
	int x0,x1,aux,i,suma;
	suma=0;
	x1=1;
	while(x1<=n){
		aux=x0;
		x0=x1;
		x1+=aux;
		i=x0+1;
		while(i<x1 && i<=n){
			suma+=i;
			printf("%d, ",i);
			i++;
		}
	}
	printf("\nLa suma es: %i",suma);
}
main()
{
	int rep;
	do{
		printf("Hasta que numero quiere llegar: ");
		scanf("%i",&n);
		figo(n);
		printf("\nDesea repetir el test: 1-SI");
		scanf("%i",&rep);
		system("cls");
		getch();
	}
	while(rep==1);
}
