#include<stdio.h>
#include<stdlib.h>

int main()
{
	float radio,resultado;
	float pi=3.1416;
	printf("Introduce el valor del radio: ");
	scanf("%f", & radio);
	resultado=pi*(radio*radio);
	printf("El area del circulo es %.2f",resultado);
	return 0;
}
