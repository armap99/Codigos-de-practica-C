#include<stdio.h>
#include<stdlib.h>

int main()
{
	int NUM;
	printf("Introduzca un nuemro entero: ");
	scanf("%i",&NUM);
	if(NUM>0)
		printf("%i es positivo \n",NUM);
	else if(NUM<0)
		printf("%i es negativo \n",NUM);
	else
		printf("%i es cero \n",NUM);
	return 0;	
}
