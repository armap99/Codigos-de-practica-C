/*Nombre:Luis Armando Prado N��ez
  Programa:Hacer una piramide de n numeros con while
  21/09/18
  D.P:Mostrar en pantalla los numeros deceados acomodados en forma de piramide*/
#include<stdio.h>
#include<conio.h>
main()
{
	int n,j,i;
	char rep;
	do{
		printf("Hasta que numero quiere realizar la figura: ");
		scanf("%i",&n);
		i=1;
		while(i<=n)
		{
			printf("\n");
			j=1;
			while(j<=n)
			{
				if(j+i>n)
				{
					printf(" %i",j+i-n);
				}
				else
					printf(" ");
				j++;
			}
			i++;
		}
		printf("\nDesea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
		system("cls");
	}
	while(rep=='S'||rep=='s');
}
