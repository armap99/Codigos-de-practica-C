/*Nombre:Luis Armando Prado N��ez
  Programa:Tablas de multiplicar 1 10 do-while
  21/09/18
  D.P:Mostrar en pantalla las tablas de multiplicar las primeras 5 en media pantalla y las otras 5 en la otra mitad*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int i,n,j;
	char rep;
	do{
		i=1;
		do{
			printf("\n");
			j=1;
			do{
				printf("%i ",j*i);
				j++;
			}
			while(j<=5);
			i++;
		}
		while(i<=10);
		i=1;
		printf("\n");
		do{
			printf("\n");
			j=6;
			do{
				printf("%i ",j*i);
				j++;
			}
			while(j<=10);
			i++;
		}
		while(i<=10);
		printf("\nDesea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
	}
	while(rep=='S'||rep=='s');
}
