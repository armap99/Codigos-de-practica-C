/*Nombre:Luis Armando Prado N��ez
  Problema:Cuantas cifras tiene un numero con for
  12/09/18
  D.P:Se ingresara un numero y te mostrara la pantalla cuantos digitos tiene*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int n,i,sob;
	printf("Introduzca un numero: ");
	scanf("%i",&n);
	sob=0;
	for(i=n;i>0;)
	{
		sob+=1;
		i/=10;
	}
	printf("Tiene %i digitos",sob);
	getch();
}
