/*Nombre:Luis Armando Prado N��ez 
  Programa:Estructuras de alumnos
  Fecha:24/10/18
  D.P:Se pediran los nombres de un alumnos y se guardaran en una estrsuctura y despues los promedios */
  
#include<stdio.h>
#include <conio.h>
main()
{
	int i,n,j,cal;
	char rep;
	float temp=0;
	struct{
		char nom[50];
		float prom;
	}alum[100];
	do{
		printf("Cuantos alumnos va a ingresar: ");
		scanf("%i",&n);
		i=0;
		do{
			printf("Ingrese el nombre :");
			fflush(stdin);gets(alum[i].nom);
			j=0;
			do{
				printf("\nIngrese %i calificacion: ",j);
				scanf("%i",&cal);
				temp+=cal;
				j++;
			}
			while(j<6);
			temp=temp/6;
			alum[i].prom=temp;
			i++;
		}
		while(i<n);
		i=0;
		do{
			printf("Nombre : %s\n",alum[i].nom);
			printf("Promedio : %f\n",alum[i].prom);
			printf("\n");
			i++;
		}
		while(i<n);
		printf("\nDeseas volver a corre el programa?\nS=si\nN=no");
		fflush(stdin);scanf("%c",&rep);
	}
	while(rep=='S' || rep=='s');
}
