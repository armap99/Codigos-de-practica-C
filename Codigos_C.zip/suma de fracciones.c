/*Nombre:Luis Armando Prado N��ez
  Programa:La suma de fracciones donde el denominador aumenta uno con for
  05/09/18
  D.P:Se pruguntara al usuari cunatas veces quiere realizar la suma y sgunsea el cazo aumentara el numerador*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int i,n;
	float a;
	char rep;
	do{
		printf("Cuantas veces quiere aumentar el denominador? ");
		scanf("%i",&n);
		a=0;
		for(i=1;i<=n;i+=1)
		{
			printf("1/%i ",i);
			a+=1/(float)i;
		}
		printf("\nEl resultado de la suma es: %f",a);
		printf("\nDesea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
	}
	while(rep=='S'||rep=='s');
}  
