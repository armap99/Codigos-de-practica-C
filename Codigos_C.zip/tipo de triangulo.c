/*Nombre:Luis Armando Prado N��ez
Practica:Tipo de triangulo
24/08/18
D.P:Mostrar en pantalla que tipo de triangulo que es segun los lados ingresados*/

#include<stdio.h>
#include<conio.h>

main()
{
	int l1,l2,l3;
	printf("Introduzca el primer lado del triangulo: ");
	scanf("%i",&l1);
	printf("Introduzca el segundo lado del triangulo: ");
	scanf("%i",&l2);
	printf("Introduzca el tercer lado del triangulo: ");
	scanf("%i",&l3);
	if(l1==l2&&l1==l3&&l2==l3)
		printf("El triangulo es equilatero \n");
	if(l1==l2&&l3!=l1||l2==l3&&l2!=l1||l3==l1&&l3!=l2)
		printf("El triangulo es isoseles \n");
	if(l1!=l2&&l1!=l3&&l3!=l2)
		printf("El triangulo es escaleno");
	
	getch();
}

