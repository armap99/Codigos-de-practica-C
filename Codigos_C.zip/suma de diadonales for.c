/*Nombre:Luis Armando Prado N��ez
  Programa:Suma de diagonales de una matriz for 
  06/10/18
  D.P:Mostrara la suma de las diagonales de la matriz y sus elementos sobrantes */
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#define t 10
main()
{
	int i,j,matriz[t][t],fc,rep,sumdp,sumds,smas;
	printf("Cuantas filas y columnas quieres max 10 ");
    scanf("%i",&fc);
    for(i=0;i<fc;i++)
    {
        for(j=0;j<fc;j++)
        {
            printf("Teclea el elemento de la matriz [%i][%i] ",i,j);
            scanf("%i",&matriz[i][j]);
            if(i==j)
			{
				sumdp+=matriz[i][j];
				if(i+j+1==fc)
					sumds+=matriz[i][j];
			}
			else if (i+j+1==fc)
				sumds+=matriz[i][j];
			else
				smas+=matriz[i][j];
        }
    }
    for(i=0;i<fc;i++)
    {
        printf("\n");
        for(j=0;j<fc;j++)
            printf("%i ",matriz[i][j]);
    }
    printf("\nDiagonal principal: %i",sumdp);
	printf("\nDiagnoal invertida: %i",sumds);
	printf("\nResto de elementos: %i",smas);
}
