/*Nombre:Luis Armando Prado N��ez
  Programa:Mostrar en una diagonal 4X4 amor con for
  06/10/18
  D.P:Mostrara una matriz 4X4 que en su diagonal diga amor  */

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#define t 10
main()
{
	int i,j,rep;
	char mat[t][t],amor[]="AMOR";
	do{
		for(i=0;i<4;i++)
		{
			printf("\n");
			for(j=0;j<4;j++)
			{
				if(i==j)
				{
					mat[i][j]=amor[i];
					printf("%c ",mat[i][j]);
				}
				else
				{
					mat[i][j]=0;
					printf("%i ",mat[i][j]);
				}
			}
		}
		printf("\nDeseas repetir el programa? 1=si ");
        scanf("%i",&rep);
	}
	while(rep==1);
}
