/*Nombre:Luis Armando Prado N��ez
  Programa:Tablas de multiplicar 1 10 while
  21/09/18
  D.P:Mostrar en pantalla las tablas de multiplicar las primeras 5 en media pantalla y las otras 5 en la otra mitad*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int i,n,j;
	char rep;
	do{
		i=1;
		while(i<=10)
		{
			printf("\n");
			j=1;
			while(j<=5)
			{
				printf("%i ",j*i);
				j++;
			}
			i++;
		}
		i=1;
		printf("\n");
		while(i<=10)
		{
			printf("\n");
			j=6;
			while(j<=10)
			{
				printf("%i ",j*i);
				j++;
			}
			i++;
		}
		printf("\nDesea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
	}
	while(rep=='S'||rep=='s');
}
