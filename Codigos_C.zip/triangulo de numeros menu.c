/*Nombre:Luis Armando Prado N��ez
  Programa:Triangulo de numeros en menu 
  21/09/18
  D.P:Mostrar en pantalla menu de los numeros deseados en forma decentente y acendente*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int n,j,i,a;
	char rep,men;
	do{
		printf("Menu de bucles\n");
		printf("F-For\nW-While\nD-Do while\n");
		fflush(stdin);scanf("%c",&men);
		switch(men)
		{
			case'f':case'F':
				a=1;
				printf("Hasta que numero quiere realizar la figura: ");
				scanf("%i",&n);
				for(i=1;i<=n;i++)
				{
					printf("\n");
					a=1;
					for(j=1;j<=i;j++)
					{
						printf("%i ",a );
						a++;
					}
				}
				for(i=1;i<=n;i++)
				{
					printf("\n");
					a=1;
					for(j=n;j>=i;j--)
					{
						printf("%i ",a );
						a++;
					}
				}
			break;
			case'w':case'W':
				a=1;
				i=1;
				printf("Hasta que numero quiere realizar la figura: ");
				scanf("%i",&n);
				while(i<=n)
				{
					printf("\n");
					a=1;
					j=1;
					while(j<=i)
					{
						printf("%i ",a );
						a++;
						j++;
					}
					i++;
				}
				i=1;
				while(i<=n)
				{
					printf("\n");
					a=1;
					j=n;
					while(j>=i)
					{
						printf("%i ",a );
						a++;
						j--;
					}
					i++;
				}
			break;
			case'd':case'D':
				a=1;
				i=1;
				printf("Hasta que numero quiere realizar la figura: ");
				scanf("%i",&n);	
				do{
					printf("\n");
					a=1;
					j=1;
					do{
						printf("%i ",a );
						a++;
						j++;	
					}
					while(j<=i);
					i++;
				}
				while(i<=n);
				i=1;
				do{
					printf("\n");
					a=1;
					j=n;
					do{
						printf("%i ",a );
						a++;
						j--;
					}
					while(j>=i);
					i++;
				}
				while(i<=n);
			break;
			default:
				printf("Error");
		}
		printf("Desea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
		system("cls");
	}
	while(rep=='S'||rep=='s');
}
