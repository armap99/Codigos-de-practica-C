/*Nombre:Luis Armando Prado N��ez
  Programa:Operaciones basicas con funciones con paso de parametro y con retorno
  17/10/18
  D.P:Mostrara en pantalla un menu de operaciones basicas que se realizaran las operaciones */
  

#include "stdio.h"
#include "conio.h"
#include "math.h"
#define p printf
#define s scanf

int a,b;
int suma (int, int);
int resta(int, int);
int multiplicacion(int, int);
float division(int, int);

int residuo(int x, int y){
	return x%y;
}

float potencia(int x, int y){
	return pow(x,y);
}

float raiz(int x){
	return sqrt(x);
}

int suma(int x, int y){
	return x+y;
}

int resta(int x, int y){
	return x-y;
}

int multiplicacion(int x, int y){
	return x*y;
}

float division(int x, int y){
	
	return x/y;
}

main(){
	int op,rep;
	do{
		p("Cual operacion basica deseas?\n1 = Suma\n2 = Resta\n3 = Multiplicacion\n4 = Division\n5 = Residuo\n6 = Potencia\n7 = Raiz cuadrada\n");
		s("%i",&op);
		p("Teclea 2 numeros enteros\n");
		s("%i%i",&a,&b);
		
		
		switch (op){
			case 1:
				p("\nLa suma de %i+%i = %i",a,b,suma(a,b));
				break;
			case 2:
				p("\nLa resta de %i-%i = %i",a,b,resta(a,b));
				break;
			case 3:
				p("\nLa multiplicacion es %i*%i = %i",a,b,multiplicacion(a,b));
				break;
			case 4:
				p("\nLa division de %i/%i = %i",a,b,division(a,b));	
				break;
			case 5:
				p("\nResiduo de %i/%i = %i",a,b,residuo(a,b));
				break;
			case 6:
				p("\nPotencia de %i^%i = %.0f",a,b,potencia(a,b));
				break;
			case 7:
				p("\nLa raiz cuadrada de %i = %.2f",a,raiz(a));
				break;
			default:
				p("Esta opcion no esta definida");
		}
		p("\nDeseas repetir el programa? 1 = si ");
		s("%i",&rep);
	}while(rep==1);
}
