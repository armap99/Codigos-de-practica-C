/*Nombre:Luis Armando Prado Nu�ez
  Problema:Menu de serie de suma de tres en tres 
  05/09/18
  D.P:Muestra en pantalla el menu de las serie de suma de tres en tres y la suma hasta un munero introducido por teclado*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int i,a,n,men;
	char rep;
	do{
	printf("Menu de bucles\n");
	printf("F-For\nW-While\nD-Do while\n");
	fflush(stdin);scanf("%c",&men);
		switch(men)
		{
			case'f':case'F':
				printf("Hasta que numero quieres sumar: ");
				scanf("%i",&n);
				a=0;
				for(i=2;i<=n;i+=3)
				{
					a=a+i;
					printf("%i ",i);
				}
				printf("La suma de tres en tres hasta %i es: %i\n",n,a);
			break;
			case'w':case'W':
				printf("Hasta que numero quieres sumar: ");
				scanf("%c",&n);
				i=2;
				a=0;
				while(i<=n)
				{
					a=a+i;
					i+=3;
					printf("%i ",i);
				}
				printf("La suma de tres en tres hasta %i es: %i\n",n,a);
			break;
			case'd':case'D':
				printf("Hasta que numero quieres sumar de tres en tres: ");
				scanf("%i",&n);
				a=0;
				i=2;
				do{
					a+=i;
					i+=3;
					printf("%i ",i);	
				}
				while(i<=n);
				printf("La suma de tres en tres hasta %i es: %i\n",n,a);
			break;	
		}
		printf("Desea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);	
	}
	while(rep=='S'||rep=='s');
}
