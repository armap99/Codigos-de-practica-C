#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int main()
{
	float r,V;
	float pi=3.1416;
	printf("Introduce el valor del radio de la esfera en cm: ");
	scanf("%f", & r);
	V=0.75*pi*pow(r,3);
	printf("El volumen del radio es: %0.2f",V);
	return 0;
}
