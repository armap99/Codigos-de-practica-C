/*Nombre:Luis Armando Prado Nu�ez
  Problema:Sumar de tres en tres a partir del 2 con while
  05/09/18
  D.P:Muestra en pantalla la serie de numeros resultantes de sumarle 3 segun lo dese el usuario*/
 
#include<stdio.h>
#include<conio.h>
main() 
{
	int i,a,n;
	char rep;
	do{
		printf("Hasta que numero quieres sumar: ");
		scanf("%c",&n);
		i=2;
		a=0;
		while(i<=n)
		{
			a=a+i;
			i+=3;
			printf("%i ",i);
		}
		printf("La suma de tres en tres hasta %i es: %i\n",n,a);
		printf("Desea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
	}
	while(rep=='S'||rep=='s');
}
