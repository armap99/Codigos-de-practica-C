/*NomProgramador> Oscar Martinez
  NomPrograma> Registro de calificaciones de alumnos
  Fecha> 24/octubre/2018
  DP> Guarda la informacion de n alumnos
*/
#include "stdio.h"
#include "conio.h"
#include "stdlib.h"
#define p printf
#define s scanf

main(){
	char rep;
	int nAlum;
	struct{
		char nom[50];
		float cal[6], prom;
	}alumno[100];
	
	
	do{
		p("Cuantos alumnos seran capturados?: ");
		s("%i",&nAlum);
		
		//Lectura de datos
		for(int i=0; i<nAlum; i++){
			p("Nombre del alumno %i: ",i+1);
			fflush(stdin);
			gets(alumno[i].nom);
			alumno[i].prom=0;
			for(int j=0; j<6; j++){
				p("\nCalificacion %i de %s: ",j+1,alumno[i].nom);
				s("%f",& alumno[i].cal[j]);
				alumno[i].prom+=alumno[i].cal[j];
			}
			alumno[i].prom/=6;
			system("cls");
			//
		}
		//Imprimir en pantalla	
		for(int i=0; i<nAlum; i++){
			p("\n\nNombre del alumno: %s ",alumno[i].nom);
			for(int j=0; j<6; j++){
				p("\nCalificacion %i: %.2f", j+1,alumno[i].cal[j]);
			}
			p("\nPromedio: %.2f",alumno[i].prom);
		}
		//
		
		p("\nDeseas volver a corre el programa?\nS=si\nN=no");
		fflush(stdin);
		s("%c",&rep);
		
	}while(rep=='S' || rep=='s');
}
