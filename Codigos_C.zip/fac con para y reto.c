/*Nombre:Luis Armando Prado N��ez
  Problema:Factorial de un munero con for y retorno y parametro
  17/10/18
  D.P:Se ingresara el numero que se quiera realizar el facorial y se mostrara en pantalla*/
  
#include<stdio.h>
#include<conio.h>
int n;
long int t;
int ria(int n)
{
	int i;
	t=1;
	for(i=n;i!=0;i-=1)
	{
		//printf("%i*",i);
		t*=i;
	}
	return t;
}

main()
{
	int rep;
	do{
		printf("Que factorial quiere realizar: ");
		scanf("%i",&n);
		ria(n);
		printf("\nEl factorial de %i es: %li",n,t);	
		printf("\nDesea repetir el grograma: 1-SI");
		scanf("%i",&rep);
		system("cls");
		getch();
	}
	while(rep==1);
}
