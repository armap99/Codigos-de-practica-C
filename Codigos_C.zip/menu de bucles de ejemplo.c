/*Nombre:Luis Armando Prado Nu�ez
  Problema:Menu de serie de impaeres y su suma con bucles
  05/09/18
  D.P:Muestra en pantalla el menu de las serie de numeros inparaes y la suma hasta un munero introducido por teclado*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int i,a,n,men;
	char rep;
	do{
	printf("Menu de bucles\n");
	printf("F-For\nW-While\nD-Do while\n");
	fflush(stdin);scanf("%c",&men);
		switch(men)
		{
			case'f':case'F':
				printf("Hasta que numero quieres los impares y su suma: ");
				scanf("%i",&n);
				a=0;
				for(i=1;i<=n;i+=2)
				{
					printf("%i ",i);
					a=a+i;
				}
				printf(" la suma de los impares hasta %i es=%i \n",n,a);
			break;
			case'w':case'W':
				printf("Hasta que numero quieres los impares y su suma: ");
				scanf("%i",&n);
				a=0;
				i=1;
				while(i<=n)
				{
					printf("%i ",i);
					a=a+i;
					i+=2;
				}
				printf(" la suma de los impares hasta %i es=%i \n",n,a);
			break;
			case'd':case'D':
				printf("Hasta que numero quieres los impares y su suma: ");
				scanf("%i",&n);
				a=0;
				i=1;
				do
				{
					printf("%i ",i);
					a=a+i;
					i+=2;
				}
				while(i<=n);
				printf(" la suma de los impares hasta %i es=%i \n",n,a);
			break;	
		}
		printf("Desea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);	
	}
	while(rep=='S'||rep=='s');
}


