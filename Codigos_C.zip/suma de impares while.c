/*Nombre:Luis Armando Prado Nu�ez
  Problema:Serie de impaeres y su suma con while
  05/09/18
  D.P:Muestra en pantalla la serie de numeros inparaes y la suma hasta un munero introducido por teclado*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int i,a,n;
	char rep;
	do{
		printf("Hasta que numero quieres los impares y su suma: ");
		scanf("%i",&n);
		a=0;
		i=1;
		while(i<=n)
		{
			printf("%i ",i);
			a=a+i;
			i+=2;
		}
		printf(" la suma de los impares hasta %i es=%i \n",n,a);
		printf("Desea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
	  }
	  while(rep=='S'||rep=='s');
}
