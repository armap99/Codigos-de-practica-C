/*Nombre:Luis Armando Prado N��ez
  Programa:Cuacrado de n tama�o menu
  21/09/18
  D.P:Mostrar en pantalla el menu para realizar un cuadrado de el tama�o que el usuario quiera con el bucle que quiera*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int n,i,j;
	char rep,men;
	do{
		printf("Menu de bucles\n");
		printf("F-For\nW-While\nD-Do while\n");
		fflush(stdin);scanf("%c",&men);
		switch(men)
		{
			case'f':case'F':
				printf("De que tama�o desea el cuadrado: ");
				scanf("%i",&n);
				for(i=1;i<=n;i++)
				{
					printf("\n");
					for(j=1;j<=n;j++)
					{
						printf("X ");
					}
				}
			break;
			case'w':case'W':
				printf("De que tama�o desea el cuadrado: ");
				scanf("%i",&n);
				i=1;
				while(i<=n)
				{
					printf("\n");
					j=1;
					while(j<=n)
					{
						printf("X ");
						j++;
					}
					i++;
				}
			break;
			case'd':case'D':
				printf("De que tama�o desea el cuadrado: ");
				scanf("%i",&n);
				i=1;
				do{
					printf("\n");
					j=1;
					do{
						printf("X ");
						j++;
					}
					while(j<=n);
					i++;
				}
				while(i<=n);
			break;
			default:
				printf("Error");
		}
		printf("\nDesea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
		system("cls");
	}
	while(rep=='S'||rep=='s');
}
