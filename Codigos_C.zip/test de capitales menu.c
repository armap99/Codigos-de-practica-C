/*Nombre:Luis Armando Prado N��ez
  Programa: Test de capitales menu
  06/10/18
  D.P:Preguntar que capital le pertenece a cada estado y decir si esta bien*/

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>  
#include<time.h> 
#include<string.h>
#define t 100
main()
{
	int hora = time(NULL),num,res,i,n,ac=0,fallos=0;
	srand(hora);
	char estado[15],capital[15],rep,men;
	char estados[t][t]={"Aguascalientes","Baja California","Baja California Sur","Campeche","Coahuila","Colima","Chiapas","Chihuahua","Distrito Federal","Durango","Guanajuato","Guerrero","Hidalgo","Jalisco","Mexico","Michoacan","Morelos","Nayarit","Nuevo Leon","Oaxaca","Puebla","Queretaro","Quintana Roo","San Luis Potosi","Sinaloa","Sonora","Tabasco","Tamaulipas","Tlaxcala","Veracruz","Yucatan","Zacatecas"};
	char capitales[t][t]={"Aguascalientes","Mexicali","La Paz","Campeche","Saltillo","Colima","Tuxtla Gutierrez","Chihuahua","Ciudad de Mexico","Durango","Guanajuato","Chilpancingo","Pachuca","Guadalajara","Toluca","Toluca","Cuernavaca","Tepic","Monterrey","Oaxaca","Puebla","Queretaro","Chetumal","San Luis Potosi","Culiacan","Hermosillo","Villahermosa","Ciudad Victoria","Tlaxcala","Xalapa","Merida","Zacatecas"};
	n = 1;
	do{
		printf("Menu de bucles\n");
		printf("F-Buscador de numeros con For\nW-Buscador de numeros con While\nD-Buscador de numeros con Do while\n");
		fflush(stdin);scanf("%c",&men);
		switch(men)
		{
			case'f':case'F':
				n = 1;
				for(i=0;i<=n;i++)
				{	
					printf("Conteste las capitales con estos estados : Aguascalientes, Baja California, Baja California Sur, Campeche, Coahuila, Colima, Chiapas, Chihuahua, Distrito Federal, Durango, Guanajuato, Guerrero, Hidalgo, Jalisco, Mexico, Michoacan, Morelos, Nayarit, Nuevo Leon, Oaxaca, Puebla, Queretaro, Quintana Roo, San Luis Potosi, Sinaloa, Sonora, Tabasco, Tamaulipas, Tlaxcala, Veracruz, Yucatan, Zacatecas");
					num = rand()%32;
					printf("\nCual es el Estado donde reside la Capital %s: ",capitales[num]);
					fflush(stdin);gets(estado);
					if(strcmp(estado,estados[num]) == 0)
					{
						printf("Correcto\n");
						ac++;
					}
					else
					{
						printf("Fallaste\n");
						fallos++;
					}
					printf("1)Si\n2)No\nDeseas volver a intentarlo: ");
					scanf("%i",&res);
					if(res == 1)
						n++;
					else
						n--;
				}
				printf("Acertaste: %i\nFallaste: %i",ac,fallos);
			break;
			case'w':case'W':
				n = 1;
				i=0;
				while(i<=n)
				{	
					printf("Conteste las capitales con estos estados : Aguascalientes, Baja California, Baja California Sur, Campeche, Coahuila, Colima, Chiapas, Chihuahua, Distrito Federal, Durango, Guanajuato, Guerrero, Hidalgo, Jalisco, Mexico, Michoacan, Morelos, Nayarit, Nuevo Leon, Oaxaca, Puebla, Queretaro, Quintana Roo, San Luis Potosi, Sinaloa, Sonora, Tabasco, Tamaulipas, Tlaxcala, Veracruz, Yucatan, Zacatecas");
					num = rand()%32;
					printf("\nCual es el Estado donde reside la Capital %s: ",capitales[num]);
					fflush(stdin);gets(estado);
					if(strcmp(estado,estados[num]) == 0)
					{
						printf("Correcto\n");
						ac++;
					}
					else
					{
						printf("Fallaste\n");
						fallos++;
					}
					printf("1)Si\n2)No\nDeseas volver a intentarlo: ");
					scanf("%i",&res);
					if(res == 1)
						n++;
					else
						n--;
					i++;
				}
				printf("Acertaste: %i\nFallaste: %i",ac,fallos);
			break;
			case'd':case'D':
				n = 1;
				i=0;
				do{	
					printf("Conteste las capitales con estos estados : Aguascalientes, Baja California, Baja California Sur, Campeche, Coahuila, Colima, Chiapas, Chihuahua, Distrito Federal, Durango, Guanajuato, Guerrero, Hidalgo, Jalisco, Mexico, Michoacan, Morelos, Nayarit, Nuevo Leon, Oaxaca, Puebla, Queretaro, Quintana Roo, San Luis Potosi, Sinaloa, Sonora, Tabasco, Tamaulipas, Tlaxcala, Veracruz, Yucatan, Zacatecas");
					num = rand()%32;
					printf("\nCual es el Estado donde reside la Capital %s: ",capitales[num]);
					fflush(stdin);gets(estado);
					if(strcmp(estado,estados[num]) == 0)
					{
						printf("Correcto\n");
						ac++;
					}
					else
					{
						printf("Fallaste\n");
						fallos++;
					}
					printf("1)Si\n2)No\nDeseas volver a intentarlo: ");
					scanf("%i",&res);
					if(res == 1)
						n++;
					else
						n--;
					i++;
				}
				while(i<=n);
				printf("Acertaste: %i\nFallaste: %i",ac,fallos);
			break;
		}
		printf("Desea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
		system("cls");
	}
	while(rep=='S'||rep=='s');
}
