/*Nombre:Luis Armando Prado N��ez
  Programa:Triangulo de numeros while
  21/09/18
  D.P:Mostrar en pantalla los numeros deseados en forma decentente y acendente*/

#include<stdio.h>
#include<conio.h>
main()
{
	int n,j,i,a;
	char rep;
	do{
		a=1;
		i=1;
		printf("Hasta que numero quiere realizar la figura: ");
		scanf("%i",&n);
		while(i<=n)
		{
			printf("\n");
			a=1;
			j=1;
			while(j<=i)
			{
				printf("%i ",a );
				a++;
				j++;
			}
			i++;
		}
		i=1;
		while(i<=n)
		{
			printf("\n");
			a=1;
			j=n;
			while(j>=i)
			{
				printf("%i ",a );
				a++;
				j--;
			}
			i++;
		}
		printf("Desea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
	}
	while(rep=='S'||rep=='s');
}
