/*Nombre:Luis Armando Prado N��ez
  Programa:Operaciones basicas con funciones
  10/10/18
  D.P:Mostrara en pantalla un menu de operaciones basicas que se realizaran las operaciones */
  
  #include<stdio.h>
  #include<stdlib.h>
  #include<conio.h>
  #include<math.h>
  void suma();
  void resta();
  void multiplicacion();
  void division();
  
  void residuo()
  {
  	int a,b;
  	printf("Ingrese dos numeros enteros : ");
  	scanf("%i %i",&a,&b);
  	printf("Residuo de %i %% %i = %i",a,b,a%b);
  }
  
  void potencia()
  {
  	int a,b;
  	printf("Ingrese dos numeros enteros : ");
  	scanf("%i %i",&a,&b);
  	printf("Potencia de %i ^ %i = %i",a,b,pow(a,b));
  }

void raiz()
  {
  	int x;
  	printf("Ingrese un numero entero : ");
  	scanf("%i",&x);
  	printf("Raiz cuadrada de %i = %.0f",x,sqrt(x));
  }
  
main()
{
	int op,opc;
	do{
		printf("Este programa realiza las operaciones basicas\n �Cual desea realizar?\n");
		printf("1-Suma\n2-Resta\n3-Multiplicacion\n4-Division\n5-Residuo\n6-Potencia\n7-Raiz\n");
		scanf("%i",&op);
		switch(op)
		{
			case 1:suma();break;
			case 2:resta();break;
			case 3:multiplicacion();break;
			case 4:division();break;
			case 5:residuo();break;
			case 6:potencia();break;
			case 7:raiz();break;
			default:
				printf("ERROR");
		}
		printf("\nDesea repetir el programa 1-Si\n");
		scanf("%i",&opc);
	}
	while(opc==1);
}

void suma()
  {
  	int a,b;
  	printf("Ingrese dos numeros enteros : ");
  	scanf("%i %i",&a,&b);
  	printf("Suma de %i + %i = %i",a,b,a+b);
  }

void resta()
  {
  	int a,b;
  	printf("Ingrese dos numeros enteros : ");
  	scanf("%i %i",&a,&b);
  	printf("Resta de %i - %i = %i",a,b,a-b);
  }

void multiplicacion()
  {
  	int a,b;
  	printf("Ingrese dos numeros enteros : ");
  	scanf("%i %i",&a,&b);
  	printf("Multiplicacion de %i * %i = %i",a,b,a*b);
  }
  
  void division()
  {
  	int a,b;
  	printf("Ingrese dos numeros enteros : ");
  	scanf("%i %i",&a,&b);
  	printf("Division de %i / %i = %.2f",a,b,a/b);
  }
