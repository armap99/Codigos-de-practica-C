#include <stdio.h>

int main ()
{
int vector[10] , i , j , aux;
int menuOpc;

do{
    printf("Menu del Vector: \n");
    printf(" [1] Ingresar datos \n [2] Orndenar ascendente \n [3] Ordenar descendente \n [4] Salir \n");
    scanf("%i",&menuOpc);
    switch(menuOpc)
    {
    case 1:
        for(i=0;i<10;i++){
            printf("Ingrese el valor %i \n",i+1);
            scanf("%i",&vector[i]);
        }
        break;
    case 2:
        printf("Vector original: \n");
        for(i=0;i<10;i++)
            printf("%i , ", vector[i]);
        printf("\n Vector ordenado: \n");
        for(i=0;i<10;i++)
            for(j=i+1;j<10;j++)
                if(vector[i]>vector[j]){
                aux = vector[i];
                vector[i] = vector[j];
                vector[j] = aux;
                }
        for(i=0;i<10;i++)
        printf("%i , ", vector[i]);
        printf("\n");
        break;
    case 3:
        printf("Vector original: \n");
        for(i=0;i<10;i++)
            printf("%i , ", vector[i]);
        printf("\n Vector ordenado: \n");
        for(i=0;i<10;i++)
            for(j=i+1;j<10;j++)
                if(vector[i]<vector[j]){
                aux = vector[i];
                vector[i] = vector[j];
                vector[j] = aux;
                }
        for(i=0;i<10;i++)
        printf("%i , ", vector[i]);
        printf("\n");
        break;
    default:
        printf("Opcion no valida \n");
    }
    }while(menuOpc!=4);

return 0;
}
