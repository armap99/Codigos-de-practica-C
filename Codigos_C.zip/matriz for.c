/*Nombre:Luis Armando Prado N��ez
  Programa:Matriz con for
  03/10/18
  D.P:Se introduciran los datos que quieran que se muestren en pantalla*/
#include<stdlib.h>
#include<conio.h>
#define t 10
main()
{
    int i,j,matriz[t][t],fc,rep;

    do
    {
        printf("Cuantas filas y columnas quieres max 10 ");
        scanf("%i",&fc);
        for(i=0;i<fc;i++)
        {
            for(j=0;j<fc;j++)
            {
                printf("Teclea el elemento de la matriz [%i][%i] ",i,j);
                scanf("%i",&matriz[i][j]);
            }
        }
        for(i=0;i<fc;i++)
        {
            printf("\n");
            for(j=0;j<fc;j++)
                printf("%i ",matriz[i][j]);
        }
        printf("\nDeseas repetir el programa? 1=si ");
        scanf("%i",&rep);
    }while(rep==1);
    getch();
}
