/*Nombre:Luis Armando Prado N��ez
  Problema:Tabla de multiplicar con for
  12/09/18
  D.P:Se ingresara el numero del cual se quiere realizar la tabla de multiplicar*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int n,res,i;
	printf("Que tabla de multiblicar quiere realizar? ");
	scanf("%i",&n);
	for(i=1;i<=10;i+=1)
		printf("%i*%i=%i\n",n,i,n*i);
	getch();
}
