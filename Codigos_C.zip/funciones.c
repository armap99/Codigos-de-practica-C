#include<stdio.h>
#include<math.h>
#define pi 3.1416
void circulo();
void caudrado();
void triangulo();

void circulo()
{
	int r;
	float a;
	printf("Intruduzaca el radio del circulo: ");
	scanf("%i",&r);
	a=(pi*pow(r,2));
	printf("El perimetro es:%f y su area es: %f\n",pi*(r*2),a);
}

void cuadrado()
{
	int l;
	printf("Intruduzaca el lado del cuadrado: ");
	scanf("%i",&l);
	printf("El perimetro es:%i El area es: %i\n",l+l+l+l,l*l);
}

void triangulo()
{
	int b,h;
	printf("Intruduzaca la base: ");
	scanf("%i",&b);
	printf("Intruduzaca la haltura: ");
	scanf("%i",&h);
	printf("el perimetro es:%i el area es:%i\n",b+b+b,(b*h)/2);
}

main()
{
	int men;
	do
	{
		printf("MENU\n1-circulo\n2-cuadrado\n3-triangulo\n4-salir\n");
		scanf("%i",&men);
		switch(men)
		{
			case 1:circulo();break;
			case 2:cuadrado();break;
			case 3:triangulo();break;
			case 4:printf("Adios");break;
		}
	}while(men!=4);
}
