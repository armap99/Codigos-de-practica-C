/*Nombre:Luis Armando Prado Nu�ez
  Problema:Sumar de tres en tres a partir del 2 con for
  05/09/18
  D.P:Muestra en pantalla la serie de numeros resultantes de sumarle 3 segun lo dese el usuario*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int i,a,n;
	char rep;
	do{
		printf("Hasta que numero quieres sumar: ");
		scanf("%i",&n);
		a=0;
		for(i=2;i<=n;i+=3)
		{
			a=a+i;
			printf("%i ",i);
		}
		printf("La suma de tres en tres hasta %i es: %i\n",n,a);
		printf("Desea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
	  }
	  while(rep=='S'||rep=='s');
}
