/*Nombre:Luis Armando Prado N��ez
Practica:Boleto de transporte
22/08/2018
Calcular el total a pagar dependiendo de los km y mostrar sus datos*/

#include<stdio.h>
#include<conio.h>
#include<math.h>
main()
{
	float tot,km;
	char des[50],nom[50];
	printf("Introdusca su nombre: ");
	fflush(stdin),gets(nom);
	printf("Introdusca el destino deseado: ");
	fflush(stdin),gets(des);
	printf("Introdusca kilometros a recorrer: ");
	scanf("%f",&km);
	tot=km*11.75;
	puts("Autobuses CUCEI");
	printf("Pasajero: ");puts(nom);
	printf("Destino: ");puts(des);
	printf("Kilometros a recorrer: %.2f \n",km);
	printf("Total a pagar: %.2f ",tot);
	
	getch();
}
