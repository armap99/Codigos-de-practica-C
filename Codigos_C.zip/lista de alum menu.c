/*Nombre:Luis Armando Prado N��ez
  Problema:Lista de alumnos do-while
  28/09/18
  D.P:Se pedira el tama�o de la lista asi como los nombres de los alumnos y se mostrara en pantalla el promedio y los alumnos arriba del promedio*/

#include <stdlib.h>
#include <stdio.h>
#define t 100
main()
{
	int cal[t],prom,i,na,ac;
	char nomalm[t][t],men,rep;
	do{
		printf("Menu de bucles\n");
		printf("F-Lista de alumnos con For\nW-Lista de alumnos con While\nD-Lista de alumnos con Do while\n");
		fflush(stdin);scanf("%c",&men);
		switch(men)
		{
			case'f':case'F':
				printf("Cuantos alumnos son ? \n");
				scanf("%i",&na);
				ac=0;
			
				for(i=0;i<na;i++)
				{
					printf("Cual es el nombre del alumno %i ",i+1);
					fflush(stdin); gets(nomalm[i]);
					printf("Teclea la calificacion de %s ",nomalm[i]);
					scanf("%i",&cal[i]);
					ac=ac+cal[i];
				}
				prom=ac/na;
				printf("\nEl promedio del grupo fue %i \n",prom);
				printf("Los alumnos por arriba del promedio fueron :\n");
				for(i=0;i<na;i++)
				{
					if(cal[i]>prom)
					printf("%s con calificacion de %i \n",nomalm[i],cal[i]);
				}
			break;
			case'w':case'W':
				printf("Cuantos alumnos son ? \n");
				scanf("%i",&na);
				ac=0;
				i=0;
				while(i<na)
				{
					printf("Cual es el nombre del alumno %i ",i+1);
					fflush(stdin); gets(nomalm[i]);
					printf("Teclea la calificacion de %s ",nomalm[i]);
					scanf("%i",&cal[i]);
					ac=ac+cal[i];
					i++;
				}
				prom=ac/na;
				printf("\nEl promedio del grupo fue %i \n",prom);
				printf("Los alumnos por arriba del promedio fueron :\n");
				i=0;
				while(i<na)
				{
					if(cal[i]>prom)
					printf("%s con calificacion de %i \n",nomalm[i],cal[i]);
					i++;
				}
			break;
			case'd':case'D':
				printf("Cuantos alumnos son ? \n");
				scanf("%i",&na);
				ac=0;
				i=0;
				do{
					printf("Cual es el nombre del alumno %i ",i+1);
					fflush(stdin); gets(nomalm[i]);
					printf("Teclea la calificacion de %s ",nomalm[i]);
					scanf("%i",&cal[i]);
					ac=ac+cal[i];
					i++;
				}
				while(i<na);
				prom=ac/na;
				printf("\nEl promedio del grupo fue %i \n",prom);
				printf("Los alumnos por arriba del promedio fueron :\n");
				i=0;
				do{
					if(cal[i]>prom)
					printf("%s con calificacion de %i \n",nomalm[i],cal[i]);
					i++;
				}
				while(i<na);
			break;
		}
		printf("Desea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
		system("cls");
	}
	while(rep=='S'||rep=='s');
}
