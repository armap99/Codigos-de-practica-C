/*Nombre:Luis Armando Prado N��ez
  Problema:N veces el nombre con while 
  12/09/18
  D.P:Se ingresara el nombre y la cantidad de veces que se repetira el nombre*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	char nom[50];
	int i,n;
	printf("Introduzca su nombre: ");
	fflush(stdin);gets(nom);
	printf("Indroduzca cuantas veces quiere repetir su nombre: ");
	scanf("%i",&n);
	i=n;
	while(i!=0)
	{
		puts(nom);
		i-=1;
	}
	getch();
}
