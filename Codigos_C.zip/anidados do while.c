/*Nombre:Luis Armando Prado N��ez
  Programa:Ciclos anidados do while
  21/09/18
  D.P:dos do-while anidados para mostrar tres holas 4 veces */

#include<stdio.h>
#include<conio.h>
main()
{
	int i,j;
	i=1;
	do{
		printf("\n");
		j=1;
		do{
			printf(" hola ");
			j++;
		}
		while(j<=3);
		i++;
	}
	while(i<=4);
	getch();
}
