/*Nombre:Luis Armando Prado N��ez
  Programa:Cuadrado de n tama�o for
  21/09/18
  D.P:Mostrar en pantalla un cuadrado de el tama�o que el usuario quiera*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int n,i,j;
	char rep;
	do{
		printf("De que tama�o desea el cuadrado: ");
		scanf("%i",&n);
		for(i=1;i<=n;i++)
		{
			printf("\n");
			for(j=1;j<=n;j++)
			{
				printf("X ");
			}
		}
		printf("\nDesea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
	}
	while(rep=='S'||rep=='s');
}
