/*Nombre:Luis Armando Prado N��ez
  Programa:Dibujo de un barco con while
  21/09/18
  D.P:Mostrar en pantalla un barco creado por ciclos*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int i,j;
	i=1;
	while(i<=4)
	{
		printf("\n");
		j=1;
		while(j<=i)
		{
			printf("  X");
			j++;
		}
		i++;
	}
	i=1;
	while(i<=2)
	{
		printf("\n");
		j=1;
		while(j<=2)
		{
			printf("  X");
			j++;
		}
		i++;
	}
	i=1;
	while(i<=4)
	{
		printf("\n");
		j=1;
		while(j<=8)
		{
			if(i+j>10||i==4&&j<=2||i==3&&j==1)
				printf("  ");
			else
				printf("X ");
			j++;
		}
		i++;
	}
	i=1;
	while(i<=2)
	{
		printf("\n");
		j=1;
		while(j<=8)
		{
			printf("~~");
			j++;
		}
		i++;
	}
}
