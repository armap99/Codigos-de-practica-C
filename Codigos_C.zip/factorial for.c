/*Nombre:Luis Armando Prado N��ez
  Problema:Factorial de un munero con for
  12/09/18
  D.P:Se ingresara el numero que se quiera realizar el facorial y se mostrara en pantalla*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int i,n;
	long int t;
	printf("Que factorial quiere realizar: ");
	scanf("%i",&n);
	t=1;
	for(i=n;i!=0;i-=1)
	{
		printf("%i*",i);
		t*=i;
	}
	printf("\nEl factorial de %i en: %li",n,t);
	getch();	
}
