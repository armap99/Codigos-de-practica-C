/*Nombre:Luis Armando Prado N��ez
  Programa:Suma de datos de una matriz while
  03/10/18
  D.P:Mostrara la matriz introducuda y la suma de sus elementos */
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#define t 10
main()
{
    int i,j,rep;
    float matriz[t][t],sumd,men=10000;
    do
    {
        printf("Menu\n");
        printf("1-Llenar matriz de 3x3\n2-Mostrar la matriz despues de haberse capturado\n3-La suma de los elementos de la matriz\n4-El valor menor\n5-Salir\n");
        scanf("%i",&rep);
        switch(rep)
        {
        	case 1:
        		i=0;
		        while(i<3)
		        {
		        	j=0;
		            while(j<3)
		            {
		                printf("Teclea el elemento de la matriz [%i][%i] ",i,j);
		                scanf("%f",&matriz[i][j]);
		                if(men>matriz[i][j])
		                {
		                	men=matriz[i][j];
						}
		                j++;
		            }
		            i++;
		        }
        	break;
        	case 2:
        		i=0;
		        while(i<3)
		        {
		        	j=0;
		            printf("\n");
		            while(j<3)
		            {
		                printf("%.2f ",matriz[i][j]);
		                j++;
		        	}
		            i++;
		        }
			break;
			case 3:
				i=0;
		        while(i<3)
		        {
		        	j=0;
		        	while(j<3)
		        	{
		        		sumd+=matriz[i][j];
		        		j++;
					}
					i++;
				}
				printf("\nLa suma de todos los datos es %.2f\n",sumd);
			break;
			case 4:
				printf("El numero menor es: %.2f\n",men);
			break;
			case 5:
				printf("Adios");
			break;
			default:
				printf("No esta definido");
		}
    }while(rep!=5);
    getch();
}
