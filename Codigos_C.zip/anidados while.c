/*Nombre:Luis Armando Prado N��ez
  Programa:Ciclos anidados while
  21/09/18
  D.P:Dos while anidados para mostrar nombres */
  
#include<stdio.h>
#include<conio.h>
main()
{
	int i,j;
	i=1;
	while(i<=4)
	{
		printf("\n");
		j=1;
		while(j<=3)
		{
			printf(" Hola ");
			j++;
		}
		i++;
	}
	getch();
}
