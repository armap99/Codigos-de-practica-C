/*Nombre:Luis Armando Prado N��ez
  Problema:Factorial de un munero con for con parametro
  12/09/18
  D.P:Se ingresara el numero que se quiera realizar el facorial y se mostrara en pantalla*/
  
#include<stdio.h>
#include<conio.h>
int n;
void fac(int n)
{
	int i;
	long int t;
	t=1;
	for(i=n;i!=0;i-=1)
	{
		printf("%i*",i);
		t*=i;
	}
	printf("\nEl factorial de %i en: %li",n,t);	
}

main()
{
	int rep;
	do{
		printf("Que factorial quiere realizar: ");
		scanf("%i",&n);
		fac(n);
		printf("\nDesea repetir el programa: 1-SI");
		scanf("%i",&rep);
		system("cls");
		getch();
	}
	while(rep==1);
}
