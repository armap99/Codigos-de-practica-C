#include<stdio.h>
#include<stdlib.h>

int main()
{
	int i,t,s,a,b;
	i=1;
	a=5;
	b=3;
	while(i<=10)
	{
		t=a*3;
		s=b*5;
		if(t<=35&&t>15||s>=15&&s<=35)
		{
			if(t>=30)
			s=0;
			printf("%i   %i\n",t,s);
		}
		i+=1;
		a+=1;
		b+=1;
	}
	return 0;
}
