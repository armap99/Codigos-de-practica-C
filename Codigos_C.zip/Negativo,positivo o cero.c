/*Nombre:Luis Armando Prado N��ez
Practica:Numero negativo,possitivo o cero
24/08/18
D.P:Mostrar en pantalla si el numero tecleado es positivo, negativo o cero */

#include<stdio.h>
#include<conio.h>
main()
{
	int N;
	printf("Introduzca un nuemro entero: ");
	scanf("%i",&N);
	if(N>0)
		printf("%i es positivo \n",N);
	if(N<0)
		printf("%i es negativo \n",N);
	if(N==0)
		printf("%i es cero \n",N);
	
	getch();	
}
