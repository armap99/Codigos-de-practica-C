/*Nombre:Luis Armando Prado N��ez
  Programa:Suma de dos matrices do-while
  06/10/18
  D.P:Mostrara las matrices a sumar y el resultado de la suma*/
  
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#define t 10
main()
{
	int j,i,fc,a[t][t],b[t][t],c[t][t],hora = time(NULL);
	srand(hora);
	char rep;
	do{
		printf("Cuantas filas y columnas quieres max 10 ");
	    scanf("%i",&fc);
	    i=0;
	    do{
	    	j=0;
	        do{
	            a[i][j]=rand()%20;
	            b[i][j]=rand()%20;
	            c[i][j]=a[i][j]+b[i][j];
	            j++;
	        }
	        while(j<fc);
	        i++;
	    }
	    while(i<fc);
	    i=0;
		do{
			printf("\n");
			j=0;
			do{
				printf("%i ",a[i][j]);
				j++;
			}
			while(j<fc);
			printf(" +  ");
			j=0;
			do{
				printf("%i ",b[i][j]);
				j++;
			}
			while(j<fc);
			printf(" == ");
			j=0;
			do{
				printf("%i ",c[i][j]);
				j++;
			}
			while(j<fc);
			i++;
		}
		while(i<fc);
		printf("\nDesea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
	}
	while(rep=='S'||rep=='s');
}
