/*Nombre:Luis Armando Prado N��ez
Practica:Hipotenusa
22/08/2018
Calcular la hipotenusa conociendo los catetos*/

#include<stdio.h>
#include<conio.h>
#include<math.h>
main()
{
	int co,ca;
	float h;
	printf("Cuanto miden los catetos del triangulo en cm ");
	scanf("%i%i",&ca,&co);
	h=sqrt(ca*ca+pow(co,2));
	printf("La hipotenusa del triangulo es= %.2f cm ",h);
	getch();
}
