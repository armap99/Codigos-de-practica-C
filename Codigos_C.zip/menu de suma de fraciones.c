/*Nombre:Luis Armando Prado Nu�ez
  Problema:Menu de serie de impaeres y su suma con bucles
  05/09/18
  D.P:Muestra en pantalla el menu de las serie de numeros inparaes y la suma hasta un munero introducido por teclado*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int i,b,c,n,men;
	float a;
	char rep;
	do{
	printf("Menu de bucles\n");
	printf("F-For\nW-While\nD-Do while\n");
	fflush(stdin);scanf("%c",&men);
		switch(men)
		{
			case'f':case'F':
				printf("Cuantas veces quiere aumentar el denominador? ");
				scanf("%i",&n);
				a=0;
				for(i=1;i<=n;i+=1)
				{
					printf("1/%i ",i);
					a+=(1/i);
				}
				printf("\nEl resultado de la suma es: %f",a);
			break;
			case'w':case'W':
				printf("Cuantas veces quiere aumentar el denominador? ");
				scanf("%i",&n);
				a=0;
				while(i<=n)
				{
					i+=1;
					printf("1/%i ",i);
					a+=(1/i);
				}
				printf("\nEl resultado de la suma es: %f",a);
			break;
			case'd':case'D':
				printf("Cuantas veces quiere aumentar el denominador? ");
				scanf("%i",&n);
				a=0;
				do{
					i+=1;
					printf("1/%i ",i);
					a+=(1/i);
				}
				while(i<=n);
				printf("\nEl resultado de la suma es: %f",a);
			break;	
		}
		printf("Desea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);	
	}
	while(rep=='S'||rep=='s');
}

