/*Nombre:Luis Armando Prado N��ez
  Programa:Mostrar en una diagonal 4X4 amor con menu
  06/10/18
  D.P:Mostrara una matriz 4X4 que en su diagonal diga amor  */
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#define t 10
main()
{
	int i,j,rep;
	char men,mat[t][t],amor[]="AMOR";
	do{
		printf("Menu de bucles\n");
		printf("F-AMOR con For\nW-AMOR con While\nD-AMOR con Do while\n");
		fflush(stdin);scanf("%c",&men);
		switch(men)
		{
			case'f':case'F':
				for(i=0;i<4;i++)
				{
					printf("\n");
					for(j=0;j<4;j++)
					{
						if(i==j)
						{
							mat[i][j]=amor[i];
							printf("%c ",mat[i][j]);
						}
						else
						{
							mat[i][j]=0;
							printf("%i ",mat[i][j]);
						}
					}
				}
			break;
			case'w':case'W':
				i=0;
				while(i<4)
				{
					printf("\n");
					j=0;
					while(j<4)
					{
						if(i==j)
						{
							mat[i][j]=amor[i];
							printf("%c ",mat[i][j]);
						}
						else
						{
							mat[i][j]=0;
							printf("%i ",mat[i][j]);
						}
						j++;
					}
					i++;
				}
			break;
			case'd':case'D':
				i=0;
				do{
					printf("\n");
					j=0;
					do{
						if(i==j)
						{
							mat[i][j]=amor[i];
							printf("%c ",mat[i][j]);
						}
						else
						{
							mat[i][j]=0;
							printf("%i ",mat[i][j]);
						}
						j++;
					}
					while(j<4);
					i++;
				}
				while(i<4);
			break;
		}
		printf("Desea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
		system("cls");
	}
	while(rep=='S'||rep=='s');
}
