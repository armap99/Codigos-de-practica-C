#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main()
{
	int i,num,po,re;
	printf("Introduce el numero que quiera elevar: ");
	scanf("%i",&num);
	printf("Introcuce la potencia a la que sea elevado: ");
	scanf("%i",&po);
	i=1;
	re=1;
	do{
		re=num*re;
		printf("%i*",num);
		i+=1;
	}
	while(i<=po);
	printf("=%i",re);
	return 0;
}
