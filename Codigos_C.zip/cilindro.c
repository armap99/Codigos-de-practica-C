#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int main()
{
	float D,H,r,V;
	float pi=3.1416;
	printf("Introduce el valor del diametro en cm: ");
	scanf("%f", & D);
	printf("Introduce el valor de la haltura en cm: ");
	scanf("%f", & H);
	r=D/2;
	V=pi*pow(r,2)*H;
	printf("El volumen del cilindro es %.2f",V);
	return 0;
}
