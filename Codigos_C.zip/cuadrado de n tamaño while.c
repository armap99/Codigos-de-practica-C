/*Nombre:Luis Armando Prado N��ez
  Programa:Cuacrado de n tama�o while
  21/09/18
  D.P:Mostrar en pantalla un cuadrado de el tama�o que el usuario quiera*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int n,i,j;
	char rep;
	do{
		printf("De que tama�o desea el cuadrado: ");
		scanf("%i",&n);
		i=1;
		while(i<=n)
		{
			printf("\n");
			j=1;
			while(j<=n)
			{
				printf("X ");
				j++;
			}
			i++;
		}
		printf("\nDesea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
	}
	while(rep=='S'||rep=='s');
}
