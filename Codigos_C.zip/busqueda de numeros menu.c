/*Nombre:Luis Armando Prado N��ez
  Programa: Numero a buscar menu 
  06/10/18
  D.P:Pedir una lista de n numero y sumar impares y pares */
  
  #include<stdio.h>
  #include<conio.h>
  #define t 100
  main()
  {
  	int n,cade[t],op,simp,spar,i,bus[t],m;
  	char rep,men;
  	do{
		printf("Menu de bucles\n");
		printf("F-Buscador de numeros con For\nW-Buscador de numeros con While\nD-Buscador de numeros con Do while\n");
		fflush(stdin);scanf("%c",&men);
		switch(men)
		{
			case'f':case'F':
				simp=0;
				spar=0;
				printf("Que tama�o quiere la cadena: ");
				scanf("%i",&n);
				for(i=0;i<n;i++)
				{
			  		printf("Valor a agregar a la lista: ");
			  		scanf("%i",&cade[i]);
				}
				printf("Que numero quiere buscar :");
				scanf("%i",&m);
				for(i=0;i<n;i++)
				{
					if(cade[i]==m)
					{
						bus[i]=i;
					}
					if(cade[i]!=m)
					{
						bus[i]=00;
					}
					if(cade[i]%2==0)
					{
						spar+=cade[i];
					}
					if(cade[i]%2!=0)
					{
						simp+=cade[i];
					}
				}
				printf("La suma de pares es: %i\n",spar);
				printf("La suma de impares es: %i\n",simp);
				printf("El %i esta en la posicion :",m);
				for(i=0;i<n;i++)
				{
					printf("%i ",bus[i]);
				}
			break;
			case'w':case'W':
				simp=0;
				spar=0;
				printf("Que tama�o quiere la cadena: ");
				scanf("%i",&n);
				i=0;
				while(i<n)
				{
			  		printf("Valor a agregar a la lista: ");
			  		scanf("%i",&cade[i]);
			  		i++;
				}
				i=0;
				printf("Que numero quiere buscar :");
				scanf("%i",&m);
				while(i<n)
				{
					if(cade[i]==m)
					{
						bus[i]=i;
					}
					if(cade[i]!=m)
					{
						bus[i]=00;
					}
					if(cade[i]%2==0)
					{
						spar+=cade[i];
					}
					if(cade[i]%2!=0)
					{
						simp+=cade[i];
					}
					i++;
				}
				printf("La suma de pares es: %i\n",spar);
				printf("La suma de impares es: %i\n",simp);
				printf("El %i esta en la posicion :",m);
				i=0;
				while(i<n)
				{
					printf("%i ",bus[i]);
					i++;
				}
			break;
			case'd':case'D':
				simp=0;
				spar=0;
				printf("Que tama�o quiere la cadena: ");
				scanf("%i",&n);
				i=0;
				do{
			  		printf("Valor a agregar a la lista: ");
			  		scanf("%i",&cade[i]);
			  		i++;
				}
				while(i<n);
				i=0;
				printf("Que numero quiere buscar :");
				scanf("%i",&m);
				do{
					if(cade[i]==m)
					{
						bus[i]=i;
					}
					if(cade[i]!=m)
					{
						bus[i]=00;
					}
					if(cade[i]%2==0)
					{
						spar+=cade[i];
					}
					if(cade[i]%2!=0)
					{
						simp+=cade[i];
					}
					i++;
				}
				while(i<n);
				printf("La suma de pares es: %i\n",spar);
				printf("La suma de impares es: %i\n",simp);
				printf("El %i esta en la posicion :",m);
				i=0;
				do{
					printf("%i ",bus[i]);
					i++;
				}
				while(i<n);
			break;
		}
		printf("Desea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
		system("cls");
	}
	while(rep=='S'||rep=='s');
  }
