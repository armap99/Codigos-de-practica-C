/*Nombre:Luis Armando Prado N��ez
  Programa:Triangulo de numeros for
  21/09/18
  D.P:Mostrar en pantalla los numeros deseados en forma decentente y acendente*/

#include<stdio.h>
#include<conio.h>
main()
{
	int n,j,i,a;
	char rep;
	do{
		a=1;
		printf("Hasta que numero quiere realizar la figura: ");
		scanf("%i",&n);
		for(i=1;i<=n;i++)
		{
			printf("\n");
			a=1;
			for(j=1;j<=i;j++)
			{
				printf("%i ",a );
				a++;
			}
		}
		for(i=1;i<=n;i++)
		{
			printf("\n");
			a=1;
			for(j=n;j>=i;j--)
			{
				printf("%i ",a );
				a++;
			}
		}
		printf("Desea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
	}
	while(rep=='S'||rep=='s');
}
