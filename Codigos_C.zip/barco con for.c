/*Nombre:Luis Armando Prado N��ez
  Programa:Dibujo de un barco con for
  21/09/18
  D.P:Mostrar en pantalla un barco creado por ciclos*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int i,j;
	for(i=1;i<=4;i++)
		{
			printf("\n");
			for(j=1;j<=i;j++)
			{
				printf("  X");
			}
		}
	for(i=1;i<=2;i++)
		{
			printf("\n");
			for(j=1;j<=2;j++)
			{
				printf("  X");
			}
		}
	for(i=1;i<=4;i++)
		{
			printf("\n");
			for(j=1;j<=8;j++)
			{
				if(i+j>10||i==4&&j<=2||i==3&&j==1)
					printf("  ");
				else
					printf("X ");
			}
		}
	for(i=1;i<=2;i++)
		{
			printf("\n");
			for(j=1;j<=8;j++)
			{
				printf("~~");
			}
		}
	getch();
}
