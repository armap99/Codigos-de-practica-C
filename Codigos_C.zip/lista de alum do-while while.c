/*Nombre:Luis Armando Prado N��ez
  Problema:Lista de alumnos do-while y while
  28/09/18
  D.P:Se pedira el tama�o de la lista asi como los nombres de los alumnos y se mostrara en pantalla el promedio y los alumnos arriba del promedio*/
  
#include <stdlib.h>
#include <stdio.h>
#define t 100
main()
{
	int cal[t],prom,i,na,ac,op;
	char nomalm[t][t];
	do{	
		printf("Cuantos alumnos son ? \n");
		scanf("%i",&na);
		ac=0;
		i=0;
		do{
			printf("Cual es el nombre del alumno %i ",i+1);
			fflush(stdin); gets(nomalm[i]);
			printf("Teclea la calificacion de %s ",nomalm[i]);
			scanf("%i",&cal[i]);
			ac=ac+cal[i];
			i++;
		}
		while(i<na);
		prom=ac/na;
		printf("\nEl promedio del grupo fue %i \n",prom);
		printf("Los alumnos por arriba del promedio fueron :\n");
		i=0;
		while(i<na)
		{
			if(cal[i]>prom)
			printf("%s con calificacion de %i \n",nomalm[i],cal[i]);
			i++;
		}
		printf("Desea repetir el programa 1=SI\n");
		scanf("%i",&op);
	}
	while(op==1);
}
