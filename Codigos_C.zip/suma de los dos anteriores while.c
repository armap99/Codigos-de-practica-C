/*Nombre:Luis Armando Prado N��ez
  Programa:La suma de los dos numeros anteriores con while
  05/09/19
  D.P:Se pruguntara al usuari cunatas veces quiere realizar la suma de los dos numeros anteriones*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int i,n,a,b,c;
	char rep;
	do{
		printf("Cuantas veces quiere realizar la suma: ");
		scanf("%i",&n);
		i=1;
		a=1;
		b=0;
		c=0;
		while(i<=n)
		{
			i+=2;
			a+=b;
			b+=a;
			printf("%i %i ",a,b);
			c=a+c+b;
		}
		printf("La suma total es: %i\n",c);
		printf("Desea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
	}
	while(rep=='S'||rep=='s');
}
