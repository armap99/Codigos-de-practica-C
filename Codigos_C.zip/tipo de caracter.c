/*Nombre:Luis Armando Prado N��ez
Practica:Vocal,consonate o caracter especial
31/08/18
D.P:contiene un switch que te indica que tipo de caracter es*/

#include<stdio.h>
#include<conio.h>
main()
{
	char as;
	printf("Introduce un caracter: ");
	fflush(stdin);scanf("%c",&as);
	switch(as)
	{
		case'a'...'u':case'A'...'U':
			printf("El caracter es vocal");
		break;
		//case'Q':case'q':case'w':case'W':case'R':case'r':case't':case'T':case'y':case'Y':case'P':case'p':case'S':case's':case'd':case'D':case'F':case'f':case'G':case'g':case'h':case'H':case'J':case'j':case'k':case'K':case'L':case'l':case'z':case'Z':case'X':case'x':case'C':case'c':case'v':case'V':case'B':case'b':case'n':case'N':case'M':case'm':
			printf("El caracter es consonante");
		break;
		default:
			printf("Es un caracter especial");
	}
	getch();
}

