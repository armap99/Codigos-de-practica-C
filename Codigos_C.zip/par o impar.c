/*Nombre:Luis Armando Prado N��ez
Practica:par o impar
24/08/18
D.P:Eavaluar si un numero es oar o impar*/

#include<stdio.h>
#include<conio.h>
main()
{
	int N;
	printf("Teclea un numero entero: ");
	scanf("%d",&N);
	if(N%2==0)
		printf("%d es par \n ",N);
	if(N%2!=0)
		printf("%d es impar \n",N);
		
	getch();
}
