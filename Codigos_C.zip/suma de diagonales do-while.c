/*Nombre:Luis Armando Prado N��ez
  Programa:Suma de diagonales de una matriz while
  06/10/18
  D.P:Mostrara la suma de las diagonales de la matriz y sus elementos sobrantes */
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#define t 10
main()
{
	int i,j,matriz[t][t],fc,rep,sumdp,sumds,smas;
	printf("Cuantas filas y columnas quieres max 10 ");
    scanf("%i",&fc);
    i=0;
    do{
    	j=0;
        do{
            printf("Teclea el elemento de la matriz [%i][%i] ",i,j);
            scanf("%i",&matriz[i][j]);
            if(i==j)
			{
				sumdp+=matriz[i][j];
				if(i+j+1==fc)
					sumds+=matriz[i][j];
			}
			else if (i+j+1==fc)
				sumds+=matriz[i][j];
			else
				smas+=matriz[i][j];
			j++;
        }
        while(j<fc);
        i++;
    }
    while(i<fc);
    i=0;
    do{
    	j=0;
        printf("\n");
            do{
            	printf("%i ",matriz[i][j]);
            	j++;
			}
			while(j<fc);
        i++;
    }
    while(i<fc);
    printf("\nDiagonal principal: %i",sumdp);
	printf("\nDiagnoal invertida: %i",sumds);
	printf("\nResto de elementos: %i",smas);
}
