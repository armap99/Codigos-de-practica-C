/*Nombre:Luis Armando Prado N��ez
Practica:Area del triangulo
22/08/2018
Calcular el area del triangulo y mostrar el resultado*/

#include<stdio.h>
#include<conio.h>
#include<math.h>
main()
{
	float ba,h,ar;
	printf("Introduce la altura del triangulo: ");
	scanf("%f",&h);
	printf("Introduce la base del triangulo: ");
	scanf("%f",&ba);
	ar=ba*h/2;
	printf("El area del triangulo es: %.2f",ar);
	getch();
}
