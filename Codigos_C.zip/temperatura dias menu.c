/*Nombre:Luis Armando Prado N��ez
  Programa: Temperatura de una semana menu
  06/10/18
  D.P:Se pediran las temperaturas de una semana y se mostrara el dia mas frio y cliente */
  
#include<stdio.h>
#include<conio.h>
#define t 100
main()
{
	int temp[t],i,a,tempa;
	char dias[7][10]={"Lunes","Martes","Miercoles","Jueves","Viernes","Sabado","Domingo"},rep,men;
	do{
		printf("Menu de bucles\n");
		printf("F-Temperatura de una semana con For\nW-Temperatura de una semana con While\nD-Temperatura de una semana con Do while\n");
		fflush(stdin);scanf("%c",&men);
		switch(men)
		{
			case'f':case'F':
				for(i=0;i<7;i++)
				{
					printf("Temeperatura del %s : ",dias[i]);
					scanf("%i",&temp[i]);
				}
				a=0;
				tempa=0;
				for(i=0;i<7;i++)
				{
					if(temp[i]>tempa)
					{
						a=i;
						tempa=temp[i];
					}
				}
				printf("El dia mas caliente fue %s con una temperatura de %i\n",dias[a],temp[a]);
				a=0;
				for(i=0;i<7;i++)
				{
					if(temp[i]<tempa)
					{
						a=i;
						tempa=temp[i];
					}	
				}
				printf("El dia mas frio fue %s con una temperatura de %i\n",dias[a],temp[a]);
			break;
			case'w':case'W':
				i=0;
				while(i<7)
				{
					printf("Temeperatura del %s : ",dias[i]);
					scanf("%i",&temp[i]);
					i++;
				}
				i=0;
				a=0;
				tempa=0;
				while(i<7)
				{
					if(temp[i]>tempa)
					{
						a=i;
						tempa=temp[i];
					}
					i++;
				}
				printf("El dia mas caliente fue %s con una temperatura de %i\n",dias[a],temp[a]);
				a=0;
				i=0;
				while(i<7)
				{
					if(temp[i]<tempa)
					{
						a=i;
						tempa=temp[i];
					}
					i++;	
				}
				printf("El dia mas frio fue %s con una temperatura de %i\n",dias[a],temp[a]);
			break;
			case'd':case'D':
				i=0;
				do{
					printf("Temeperatura del %s : ",dias[i]);
					scanf("%i",&temp[i]);
					i++;
				}
				while(i<7);
				i=0;
				a=0;
				tempa=0;
				do{
					if(temp[i]>tempa)
					{
						a=i;
						tempa=temp[i];
					}
					i++;
				}
				while(i<7);
				printf("El dia mas caliente fue %s con una temperatura de %i\n",dias[a],temp[a]);
				a=0;
				i=0;
				do{
					if(temp[i]<tempa)
					{
						a=i;
						tempa=temp[i];
					}
					i++;	
				}
				while(i<7);
				printf("El dia mas frio fue %s con una temperatura de %i\n",dias[a],temp[a]);
			break;
		}
		printf("Desea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
		system("cls");
	}
	while(rep=='S'||rep=='s');
}
