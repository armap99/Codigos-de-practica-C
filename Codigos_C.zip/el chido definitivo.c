/*Nombre:Luis Armando Prado N��ez
  Programa:Funcion no figo con parametro y con retorno
  17/10/18
  D.P:Una fincion que sera la no sucesion de fibonacci*/
  
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
int n,suma;
int figo(int n)
{
	int x0,x1,aux,i;
	suma=0;
	x1=1;
	while(x1<=n){
		aux=x0;
		x0=x1;
		x1+=aux;
		i=x0+1;
		while(i<x1 && i<=n){
			suma+=i;
			i++;
		}
	}
	return suma;
}
main()
{
	int rep;
	do{
		printf("Hasta que numero quiere llegar: ");
		scanf("%i",&n);
		figo(n);
		printf("\nLa suma es: %i",suma);
		printf("\nDesea repetir el test: 1-SI");
		scanf("%i",&rep);
		system("cls");
		getch();
	}
	while(rep==1);
}
