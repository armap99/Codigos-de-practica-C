/*Nombre:Luis Armando Prado N��ez
  Programa:Suma de diagonales de una matriz while
  06/10/18
  D.P:Mostrara la suma de las diagonales de la matriz y sus elementos sobrantes */
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#define t 10
main()
{
	int i,j,matriz[t][t],fc,rep,sumdp,sumds,smas;
	printf("Cuantas filas y columnas quieres max 10 ");
    scanf("%i",&fc);
    i=0;
    while(i<fc)
    {
    	j=0;
        while(j<fc)
        {
            printf("Teclea el elemento de la matriz [%i][%i] ",i,j);
            scanf("%i",&matriz[i][j]);
            if(i==j)
			{
				sumdp+=matriz[i][j];
				if(i+j+1==fc)
					sumds+=matriz[i][j];
			}
			else if (i+j+1==fc)
				sumds+=matriz[i][j];
			else
				smas+=matriz[i][j];
			j++;
        }
        i++;
    }
    i=0;
    while(i<fc)
    {
    	j=0;
        printf("\n");
        while(j<fc)
            {
            	printf("%i ",matriz[i][j]);
            	j++;
			}
        i++;
    }
    printf("\nDiagonal principal: %i",sumdp);
	printf("\nDiagnoal invertida: %i",sumds);
	printf("\nResto de elementos: %i",smas);
}
