/*Nombre:Luis Armando Prado N��ez
  Problema:Factorial de un munero con while
  12/09/18
  D.P:Se ingresara el numero que se quiera realizar el facorial y se mostrara en pantalla*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int i,n;
	long int t;
	printf("Que factorial quiere realizar: ");
	scanf("%i",&n);
	t=1;
	i=n;
	while(i!=0)
	{
		printf("%i*",i);
		t*=i;
		i-=1;
	}
	printf("\nEl factorial de %i en: %i",n,t);
	getch();	
}
