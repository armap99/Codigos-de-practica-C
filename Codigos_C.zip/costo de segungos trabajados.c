/*Nombre:Luis Armando Prado N��ez
Practica:Costo de proceso
24/08/18
D.P:Mostrar la cantidad total de segundos segun los datos introducidos*/

#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
main()
{
int sem,di,hr,min,seg,mint;
long int total,semt,dit,hrt,totalc;
printf("Introduzca las semanas trabajadas: ");
scanf("%d",&sem);
printf("Introduzca los dias trabajados: ");
scanf("%d",&di);
printf("Introduzca las horas trabajadas: ");
scanf("%d",&hr);
printf("Introduzca los minutos trabajados: ");
scanf("%d",&min);
printf("Introduzca los segundos trabajados: ");
scanf("%d",&seg);
semt=sem*604800;
dit=di*86400;
hrt=hr*3600;
mint=min*60;
total=semt+dit+hrt+mint+seg;
if(total>100000)
	totalc=total*.25;
if(total<=100000)
	totalc=total*.50;
system("cls");
printf("El costo del preoceso es: %i",totalc);

getch();	
}
