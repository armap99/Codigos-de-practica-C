/*Nombre:Luis Armando Prado N��ez
  Programa:Dibujo de un barco menu
  21/09/18
  D.P:Mostrar en pantalla un barco creado por ciclos dependiendo del ciclo que escoja con el menu*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int n,j,i,a;
	char rep,men;
	do{
		printf("Menu de bucles\n");
		printf("F-For\nW-While\nD-Do while\n");
		fflush(stdin);scanf("%c",&men);
		switch(men)
		{
			case'f':case'F':
				for(i=1;i<=4;i++)
				{
					printf("\n");
					for(j=1;j<=i;j++)
					{
						printf("  X");
					}
				}
			for(i=1;i<=2;i++)
				{
					printf("\n");
					for(j=1;j<=2;j++)
					{
						printf("  X");
					}
				}
			for(i=1;i<=4;i++)
				{
					printf("\n");
					for(j=1;j<=8;j++)
					{
						if(i+j>10||i==4&&j<=2||i==3&&j==1)
							printf("  ");
						else
							printf("X ");
					}
				}
			for(i=1;i<=2;i++)
				{
					printf("\n");
					for(j=1;j<=8;j++)
					{
						printf("~~");
					}
				}
			break;
			case'w':case'W':
				i=1;
				while(i<=4)
				{
					printf("\n");
					j=1;
					while(j<=i)
					{
						printf("  X");
						j++;
					}
					i++;
				}
				i=1;
				while(i<=2)
				{
					printf("\n");
					j=1;
					while(j<=2)
					{
						printf("  X");
						j++;
					}
					i++;
				}
				i=1;
				while(i<=4)
				{
					printf("\n");
					j=1;
					while(j<=8)
					{
						if(i+j>10||i==4&&j<=2||i==3&&j==1)
							printf("  ");
						else
							printf("X ");
						j++;
					}
					i++;
				}
				i=1;
				while(i<=2)
				{
					printf("\n");
					j=1;
					while(j<=8)
					{
						printf("~~");
						j++;
					}
					i++;
				}
			break;
			case'd':case'D':
				i=1;
				do{
					printf("\n");
					j=1;
					do{
						printf("  X");
						j++;
					}
					while(j<=i);
					i++;
				}
				while(i<=4);
				i=1;
				do{
					printf("\n");
					j=1;
					do{
						printf("  X");
						j++;
					}
					while(j<=2);
					i++;
				}
				while(i<=2);
				i=1;
				do{
					printf("\n");
					j=1;
					do{
						if(i+j>10||i==4&&j<=2||i==3&&j==1)
							printf("  ");
						else
							printf("X ");
						j++;
					}
					while(j<=8);
					i++;
				}
				while(i<=4);
				i=1;
				do{
					printf("\n");
					j=1;
					do{
						printf("~~");
						j++;
					}
					while(j<=8);
					i++;
				}
				while(i<=2);
		}
		printf("Desea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
		system("cls");
	}
	while(rep=='S'||rep=='s');
}
