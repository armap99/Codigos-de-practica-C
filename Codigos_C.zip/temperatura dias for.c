/*Nombre:Luis Armando Prado N��ez
  Programa: Temperatura de una semana for 
  06/10/18
  D.P:Se pediran las temperaturas de una semana y se mostrara el dia mas frio y cliente */
  
#include<stdio.h>
#include<conio.h>
#define t 100
main()
{
	int temp[t],i,a,tempa,op;
	char dias[7][10]={"Lunes","Martes","Miercoles","Jueves","Viernes","Sabado","Domingo"};
	do{
		for(i=0;i<7;i++)
		{
			printf("Temeperatura del %s : ",dias[i]);
			scanf("%i",&temp[i]);
		}
		a=0;
		tempa=0;
		for(i=0;i<7;i++)
		{
			if(temp[i]>tempa)
			{
				a=i;
				tempa=temp[i];
			}
		}
		printf("El dia mas caliente fue %s con una temperatura de %i\n",dias[a],temp[a]);
		a=0;
		for(i=0;i<7;i++)
		{
			if(temp[i]<tempa)
			{
				a=i;
				tempa=temp[i];
			}	
		}
		printf("El dia mas frio fue %s con una temperatura de %i\n",dias[a],temp[a]);
		printf("Desea repetir el programa 1=SI\n");
		scanf("%i",&op);
	}
	while(op==1);
	getch();
}
