/*Nombre:Luis Armando Prado N��ez
Practica:�rea de un circulo
22/08/2018
Calcular el area del circulo conociendo el radio*/

#include<stdio.h>
#include<conio.h>
#include<math.h>
#define pi 3.1416

main()
{
	float r,a;
	printf("Introduce el valor del radio: ");
	scanf("%f",&r);
	a=(pi*pow(r,2));
	printf("El area del circulo es %.2f",a); 

	getch();
}
