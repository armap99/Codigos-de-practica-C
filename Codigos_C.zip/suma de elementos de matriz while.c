/*Nombre:Luis Armando Prado N��ez
  Programa:Suma de datos de una matriz while
  03/10/18
  D.P:Mostrara la matriz introducuda y la suma de sus elementos */
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#define t 10
main()
{
    int i,j,matriz[t][t],fc,rep,sumd;
    do
    {
        printf("Cuantas filas y columnas quieres max 10 ");
        scanf("%i",&fc);
        i=0;
        while(i<fc)
        {
        	j=0;
            while(j<fc)
            {
                printf("Teclea el elemento de la matriz [%i][%i] ",i,j);
                scanf("%i",&matriz[i][j]);
                j++;
            }
            i++;
        }
        i=0;
        while(i<fc)
        {
        	j=0;
            printf("\n");
            while(j<fc)
            {
                printf("%i ",matriz[i][j]);
                j++;
        	}
            i++;
        }
        i=0;
        while(i<fc)
        {
        	j=0;
        	while(j<fc)
        	{
        		sumd+=matriz[i][j];
        		j++;
			}
			i++;
		}
		printf("\nLa suma de todos los datos es %i",sumd);
        printf("\nDeseas repetir el programa? 1=si ");
        scanf("%i",&rep);
    }while(rep==1);
    getch();
}
