/*Nombre:Luis Armando Prado N��ez
  Programa:Tablas de multiplicar 1 10 menu 
  21/09/18
  D.P:Mostrar en pantalla el menu de  las tablas de multiplicar las primeras 5 en media pantalla y las otras 5 en la otra mitad*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int i,n,j;
	char rep,men;
	do{
		printf("Menu de bucles\n");
		printf("F-For\nW-While\nD-Do while\n");
		fflush(stdin);scanf("%c",&men);
		switch(men)
		{
			case'f':case'F':
				for(i=1;i<=10;i++)
				{
					printf("\n");
					for(j=1;j<=5;j++)
					{
						printf("%i ",j*i);
					}
				}
				printf("\n");
				for(i=1;i<=10;i++)
				{
					printf("\n");
					for(j=6;j<=10;j++)
					{
						printf("%i ",j*i);
					}
				}
			break;
			case'w':case'W':
				i=1;
				while(i<=10)
				{
					printf("\n");
					j=1;
					while(j<=5)
					{
						printf("%i ",j*i);
						j++;
					}
					i++;
				}
				i=1;
				printf("\n");
				while(i<=10)
				{
					printf("\n");
					j=6;
					while(j<=10)
					{
						printf("%i ",j*i);
						j++;
					}
					i++;
				}
			break;
			case'd':case'D':
				i=1;
				do{
					printf("\n");
					j=1;
					do{
						printf("%i ",j*i);
						j++;
					}
					while(j<=5);
					i++;
				}
				while(i<=10);
				i=1;
				printf("\n");
				do{
					printf("\n");
					j=6;
					do{
						printf("%i ",j*i);
						j++;
					}
					while(j<=10);
					i++;
				}
				while(i<=10);
			break;
			default:
				printf("Error");
		}
		printf("\nDesea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
		system("cls");
	}
	while(rep=='S'||rep=='s');
}
