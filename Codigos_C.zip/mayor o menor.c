/*Nombre:Luis Armando Prado N��ez
Practica:Cual es mayor o menor
24/08/18
D.P:Mostrar en pantalla cual de los dos numeros introducidos es mayo y menor segun sea el caso*/

#include<stdio.h>
#include<conio.h>

main()
{
int n1,n2;
printf("Introduzca el primer numero entero: ");
scanf("%d",&n1);
printf("Introduzca el segundo numero entero: ");
scanf("%d",&n2);
if(n1>n2)
	printf("%d es mayor que %d",n1,n2);
if(n1<n2)
	printf("%d es menor que %d",n1,n2);	
if(n1==n2)
	printf("%d son iguales %d",n1,n2);
	
getch();
}
