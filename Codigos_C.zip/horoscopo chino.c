/*Nombre:Luis Armando Prado N��ez
Practica:Horoscopo chino
31/08/18
D.P:Segun en el a�o que naciste se mostrara en pantalla que horoscopo chino eres*/

#include<stdio.h>
#include<conio.h>
main()
{
	char nom[50];
	int aoe,ao;
	printf("Introduzca su nombre: ");
	fflush(stdin);scanf("%c",&nom);
	printf("Introduzca su a�o de nacimiento: ");
	scanf("%i",&ao);
	aoe=ao%12;
	switch(aoe)
	{
		case 1:
			printf("Tu signo chino es gallina");
		break;
		case 2:
			printf("Tu signo chino es perro");
		break;
		case 3:
			printf("Tu signo chino es puerco");
		break;
		case 4:
			printf("Tu signo chino es rata");
		break;
		case 5:
			printf("Tu signo chino es bufalo");
		break;
		case 6:
			printf("Tu signo chino es tigre");
		break;
		case 7:
			printf("Tu signo chino es conejo");
		break;
		case 8:
			printf("Tu signo chino es dragon");
		break;
		case 9:
			printf("Tu signo chino es serpiente");
		break;
		case 10:
			printf("Tu signo chino es caballo");
		break;
		case 11:
			printf("Tu signo chino es chiva");
		break;
		case 12:
			printf("Tu signo chino es mono");
		break;
		default:
			printf("ese a�o no es valido");
	}
	getch();
}
