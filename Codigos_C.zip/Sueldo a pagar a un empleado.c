/*Nombre:Luis Armando Prado N��ez
Practica:Sueldo a pagar y datos del empleado
22/08/2018
Calcular el impuesto,total a pagar de un empleado y mostrar sus datos*/

#include<stdio.h>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
main()
{
	float iva,total,cost,sueld;
	int hor;
	char dep[50],pues[50],nom[50];
	printf("Introdusca su nombre: ");
	fflush(stdin),gets(nom);
	printf("Introduzca el puesto que desempe�a: ");
	fflush(stdin),gets(pues);
	printf("Introduzca el departamento en el que trabaja: ");
	fflush(stdin),gets(dep);
	printf("Introdusca las horas trabajadas: ");
	scanf("%i",&hor);
	printf("Introdusca costo de hora: ");
	scanf("%f",&cost);
	sueld=hor*cost;
	iva=sueld*.16;
	total=sueld-iva;
	system("cls");
	puts("CUCEI");
	printf("Nombres: ");puts(nom);
	printf("Departamento: ");puts(dep);
	printf("Horas trabajadas: %i \n",hor);
	printf("Costo de hora: %.2f \n",cost);
	printf("Sueldo: %.2f \n",sueld);
	printf("IVA: %.2f \n",iva);
	printf("Total a pagar: %.2f \n",total);
	
	getch();
}
