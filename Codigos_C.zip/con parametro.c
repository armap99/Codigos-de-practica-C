#include<stdio.h>
#include<math.h>
void seno(int);
void coseno(int);
void tnagente(int);

void seno(int va)
{
	float re;
	re=sin(va);
	printf("El el seno en radianes es: %.2f\n",re);
}

void coseno(int va)
{
	float re;
	re=cos(va);
	printf("El el coseno en radianes es: %.2f\n",re);
}

void tangente(int va)
{
	float re;
	re=tan(va);
	printf("El el tangente en radianes es: %.2f\n",re);
}

main()
{
	int men,va;
	do
	{
		printf("ingrese el valor al que le quiera realizar la operacion:\n");
		scanf("%i",&va);
		printf("MENU\n1-seno\n2-coseno\n3-tangente\n4-salir\n");
		scanf("%i",&men);
		switch(men)
		{
			case 1:seno(va);break;
			case 2:coseno(va);break;
			case 3:tangente(va);break;
			case 4:printf("Adios");break;
		}
	}while(men!=4);
}
