/*Nombre:Luis Armando Prado N��ez
  Programa: Numero a buscar for 
  06/10/18
  D.P:Pedir una lista de n numero y sumar impares y pares */
  
  #include<stdio.h>
  #include<conio.h>
  #define t 100
  main()
  {
	int n,cade[t],op,simp,spar,i,bus[t],m;
	simp=0;
	spar=0;
	printf("Que tama�o quiere la cadena: ");
	scanf("%i",&n);
	for(i=0;i<n;i++)
	{
  		printf("Valor a agregar a la lista: ");
  		scanf("%i",&cade[i]);
	}
	printf("Que numero quiere buscar :");
	scanf("%i",&m);
	for(i=0;i<n;i++)
	{
		if(cade[i]==m)
		{
			bus[i]=i;
		}
		if(cade[i]!=m)
		{
			bus[i]=00;
		}
		if(cade[i]%2==0)
		{
			spar+=cade[i];
		}
		if(cade[i]%2!=0)
		{
			simp+=cade[i];
		}
	}
	printf("La suma de pares es: %i\n",spar);
	printf("La suma de impares es: %i\n",simp);
	printf("El %i esta en la posicion :",m);
	for(i=0;i<n;i++)
	{
		printf("%i ",bus[i]);
	}
	getch();
  }
