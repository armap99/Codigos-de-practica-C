/*Nombre:Luis Armando Prado N��ez 
  Programa:Estructuras de empelados
  Fecha:24/10/18
  D.P:Se pediran los nombres de un empleado y se guardaran en una estrsuctura y despues los mostrara todos en pantalla*/
  
#include<stdio.h>
#include <conio.h>
#define p printf
#define s scanf
main(){
	char rep;
	int n,i;
	struct{
		char nom[50];
		int hrT;
		float sb, imp, tp, ch;
	}empleado[100];
	
	do{
		p("Cuantos empleados va a ingresar: ");
		s("%i",&n);
		for(i=0;i<n;i++)
		{
			p("Nombre del empleado: ");
			fflush(stdin);
			gets(empleado[i].nom);
			p("\nHoras trabajadas de %s: ",empleado[i].nom);
			s("%i",& empleado[i].hrT);
			p("\nCosto de hora trabajada de %s: ",empleado[i].nom);
			s("%f",&empleado[i].ch);
			empleado[i].sb = empleado[i].hrT * empleado[i].ch;
			empleado[i].imp = empleado[i].sb * .16;
			empleado[i].tp = empleado[i].sb - empleado[i].imp;
		}
		for(i=0;i<n;i++)
		{
			p("\nNombre del empelado: %s ",empleado[i].nom);
			p("\nHoras trabajadas: %i",empleado[i].hrT);
			p("\nCosto de hora: $ %.2f",empleado[i].ch);
			p("\nSueldo base: $ %.2f",empleado[i].sb);
			p("\nImpuesto: %.2f",empleado[i].imp);
			p("\nTotal a pagar: %.2f",empleado[i].tp);
			p("\n \n");
		}
		p("\nDeseas volver a corre el programa?\nS=si\nN=no");
		fflush(stdin);
		s("%c",&rep);
	}while(rep=='S' || rep=='s');
}
