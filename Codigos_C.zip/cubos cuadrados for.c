/*Nombre:Luis Armando Prado N��ez
  Problema: Elevar n numeros al cubo y al cuadrado con un bucle for
  12/09/18
  D.P:Se intruducira un numero que sera hasta el que se realice la potencia y si la pontencia es mayor a 50 se sumara a un contador y si el cubo mayor a 75 tambien*/
  
#include<stdio.h>
#include<conio.h>
#include<math.h>
main()
{
	int n,i;
	long int rca,rcb,con,cont;
	printf("Ingresa hasta que numero quieres que sean los cubos y cuadrados: ");
	scanf("%i",&n);
	con=0;
	rca=0;
	rcb=0;
	printf("Numero  Cuadrado  Cubo\n");
	for(i=1;i<=n;i+=1)
	{
		rca=pow(i,2);
		rcb=pow(i,3);
		printf("%i       %i         %i\n",i,rca,rcb);
		if(rca>50)
			con+=1;
		if(rcb>75)
			cont+=1;
	}
	printf("Cuadrados mayores a 50: %i\n",con);
	printf("Cubos mayores a 75: %i\n",cont);
	getch();
}
