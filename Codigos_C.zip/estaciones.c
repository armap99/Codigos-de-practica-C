/*Nombre:Luis Armando Prado N��ez
Practica:Estacion
31/08/18
D.P:Segun en el mes que introdusca el programa te dira en que estacion naciste*/

#include<stdio.h>
#include<conio.h>
main()
{
	char var[50],mes;
	printf("Introduzca su nombre: ");
	fflush(stdin);scanf("%c",&var);
	printf("E e-Enero\nF f-Febrero\nM m-Marzo,\nA a-Abril\nZ z-Mayo\nJ j-Junio\nL l-Julio\nG g-Agosto\nS s-Septiembre\nO o-Octubre\nN n-Noviembre\nD d-Diciembre\n");
	printf("Introduzca su mes de nacimiento: ");
	fflush(stdin);scanf("%c",&mes);
	switch(mes)
	{
		case'D':case'd':case'E':case'e':case'F':case'f':case'M':case'm':
			printf("Naciste en invierno");
		break;
		case'A':case'a':case'Z':case'z':
			printf("Naciste en primavera");
		break;
		case'J':case'j':case'L':case'l':case'G':case'g':case'S':case's':
			printf("Naciste en verano");
		break;
		case'O':case'o':case'N':case'n':
			printf("Naciste en oto�o");
		break;
		default:
			printf("Variable no valida");
	}
	getch();
}
