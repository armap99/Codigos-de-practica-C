/*Nombre:Luis Armando Prado N��ez
  Programa:Tablas de multiplicar 1 10 for
  21/09/18
  D.P:Mostrar en pantalla las tablas de multiplicar las primeras 5 en media pantalla y las otras 5 en la otra mitad*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int i,n,j;
	char rep;
	do{
		for(i=1;i<=10;i++)
		{
			printf("\n");
			for(j=1;j<=5;j++)
			{
				printf("  %i*%i=%i \t",i,j,j*i);
			}
		}
		printf("\n");
		printf("\n");
		for(i=1;i<=10;i++)
		{
			printf("\n");
			for(j=6;j<=10;j++)
			{
				printf("  %i*%i=%i \t",i,j,j*i);
			}
		}
		printf("\nDesea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
	}
	while(rep=='S'||rep=='s');
}
