/*Nombre:Luis Armando Prado N��ez
  Problema:Factorial de un munero con do while
  12/09/18
  D.P:Se ingresara el numero que se quiera realizar el facorial y se mostrara en pantalla*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int i,n;
	long int t;
	printf("Que factorial quiere realizar: ");
	scanf("%i",&n);
	t=1;
	i=n;
	do{
		printf("%i*",i);
		t*=i;
		i-=1;
	}
	while(i!=0);
	printf("\nEl factorial de %i en: %li",n,t);
	getch();	
}
