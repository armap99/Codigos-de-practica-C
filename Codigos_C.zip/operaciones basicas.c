/*Nombre:Luis Armando Prado N��ez
 Proyecto:Operaciones basicas 
 29/08/18
 DP:Contiene un menu con las operaciones basicas donde el usuario escoge que operaciones calcular*/
 
 #include<stdio.h>
 #include<conio.h>
 #include<math.h>
 main()
 {
 	char ope;
 	int x,y;
 	printf("Teclea 2 numeros enteros: ");
 	scanf("%d%d",&x,&y);
 	printf("Que operacion desea realizar");
 	printf("+ A a=Suma\n - R r=Resta\n * M m=Multiplicacion\n / D d=Division\n %c E e=Residuo\n C c=Raiz cuadrada\n ^ P p=Potencia\n S s=seno\n O o=Coseno\n T t=tangente\n",37);
 	fflush(stdin);scanf("%c",&ope);
 	switch(ope)
 	{
 		case'+':case'A':case'a':printf("Suma de %i+%i=%i",x,y,x+y);break;
 		case'-':case'R':case'r':printf("Resta de %i-%i=%i",x,y,x-y);break;
 		case'*':case'M':case'm':printf("Multiplicacion de %i*%i=%i",x,y,x*y);break;
 		case'/':case'D':case'd':printf("Division de %i/%i=%i",x,y,x/y);break;
 		case'%':case'E':case'e':printf("Residuo de %i % %i=%i",x,y,x%y);break;
 		case'C':case'c':printf("Potencia de %i^%i=%.2f",x,y,pow(x,y));break;
 		case'S':case's':printf("Seno de %i+%i=%.2f",x,y,sin(x+y));break;
 		case'O':case'o':printf("Coseno de %i+%i=%.2f",x,y,cos(x+y));break;
 		case'T':case't':printf("Tangente de %i+%i=%.2f",x,y,tan(x+y));break;
 		default:printf("No existe esa operacion");
	 }
	 getch();
 }
