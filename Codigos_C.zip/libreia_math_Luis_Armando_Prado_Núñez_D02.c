#include <stdio.h>
#include<math.h>

int main ()
{
int menuOpc;
float resultado,dato,elv;
do{
    printf("Menu del Vector: \n");
    printf("1-Arcotangente \n2-Coseno \n3-Elevar un numero \n4-Salir \n");
    scanf("%i",&menuOpc);
    switch(menuOpc)
    {
    case 1:
    	printf("Ingrese al valor que quiere sacer el arcotangente: ");
    	scanf("%f",&dato);
    	resultado=atan(dato);
    	printf("El arcotangente es %.2f \n",resultado);
    break;
    case 2:
    	printf("Ingrese al valor que quiere sacer el coseno: ");
    	scanf("%f",&dato);
    	resultado=cos(dato);
    	printf("El coseno es %.2f \n",resultado);
    break;
    case 3:
		printf("Ingrese el valor que quiere elevar:");
		scanf("%f",&dato);
		printf("Ingrese a la potencia que lo quiere elevar: ");
		scanf("%f",&elv);
		resultado=pow(dato,elv);
		printf("El resultado es: %.2f  \n",resultado);   
    break;
    default:
        printf("Opcion no valida \n");
    }
    }
	while(menuOpc!=4);

return 0;
}
