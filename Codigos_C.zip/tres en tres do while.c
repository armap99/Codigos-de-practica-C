/*Nombre:Luis Armando Prado Nu�ez
  Problema:Sumar de tres en tres a partir del 2 con do while
  05/09/18
  D.P:Muestra en pantalla la serie de numeros resultantes de sumarle 3 segun lo dese el usuario*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int i,n,a;
	char rep;
	printf("Hasta que numero quiere sumar de tres en tres: ");
	scanf("%i",&n);
	a=0;
	i=2;
	do{
		do{
			a+=i;
			i+=3;
			printf("%i ",i);	
		}
		while(i<=n);
		printf("La suma de tres en tres hasta %i es: %i\n",n,a);
		printf("Desea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
	}
	while(rep=='S'||rep=='s');
}
