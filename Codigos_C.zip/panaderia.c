/*Nombre:Luis Armando Prado N��ez
Practica:Panaderia
24/08/18
D.P:Mostrar la cantidad total a pagra de la combra de 5 productos y hacer descuento si el total es mayor a 100*/

#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
main()
{
	int pa,con,bo,don,cuer;
	float total,totd,tf,pat,cont,bot,dont,cuert;
	printf("Cuantas donas: ");
	scanf("%i",&don);
	printf("Cuantas rebanadas de pastel: ");
	scanf("%i",&pa);
	printf("Cuantas conchas: ");
	scanf("%i",&con);
	printf("Cuantos bolillos: ");
	scanf("%i",&bo);
	printf("Cuantos cuernitos: ");
	scanf("%i",&cuer);
	dont=don*12;
	pat=pa*25;
	cont=con*5;
	bot=bo*8;
	cuert=cuer*7;
	total=dont+pat+cont+bot+cuert;
	system("cls");
	printf("Cantidad Descripcion Precio Total \n");
		printf("  %i        Dona        12   %.2f \n",don,dont);
		printf("  %i       Pastel       25   %.2f \n",pa,pat);
		printf("  %i       Concha       05   %.2f \n",con,cont);
		printf("  %i       Bolillo      08   %.2f \n",bo,bot);
        printf("  %i       Cuernito     07   %.2f \n",cuer,cuert);

	if(total<100||total==100)	

		printf("Total: %.2f \n",total);
	
	if(total>100)
	{
	
		totd=total*.15;
		tf=total-totd;
	
		printf("Total: %.2f \n",total);
		printf("Total con descuento: %.2f \n",tf);
	}
	getch();
}
