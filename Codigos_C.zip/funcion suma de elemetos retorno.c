/*Nombre:Luis Armando Prado N��ez
  Programa:Suma de elementos de lista y matriz 
  17/10/18
  D.P:Mostrara en pantalla la suma de los elemntos de una matriz y lista */
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#define t 10
#include<time.h>
int n;

int lista()
{
	int o,al,lista[t],tot;
	srand(time(NULL));
	printf("De que tama�o desa la lista y matriz: ");
	scanf("%i",&n);
	tot=0;
	for(o=0;o<n;o++)
	{
		al=rand()%10;
		lista[o]=al;
		tot+=lista[o];
		//printf("%i ",lista[o]);
	}
	//printf("\n");
	return tot;
}
int matriz()
{
	printf("De que tama�o desa la lista y matriz: ");
	scanf("%i",&n);
	int i,j,matriz[t][t],rep,sumd,numi;
    srand(time(NULL));
    for(i=0;i<n;i++)
        {
        	//printf("\n");
            for(j=0;j<n;j++)
            {
                numi=rand()%10;
                matriz[i][j]=numi;
                sumd+=matriz[i][j];
                //printf("%i ",matriz[i][j]);
            }
        }
		return sumd;
}

main()
{
	int rep;
	do{
		printf("\nLa suma de todos los datos es %i\n",matriz());
		printf("\nLa suma de todos los elemetos es %i\n",lista());
		printf("\nDesea repetir : 1-SI");
		scanf("%i",&rep);
		system("cls");
		getch();
	}
	while(rep==1);
}
