/*Nombre:Luis Armando Prado N��ez
  Programa: Menu de funciones
  10/10/18
  D.P:Se montrara un menu de las funciones donde podras ejecutar el que el usuario quiera*/

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>  
#include<time.h> 
#include<string.h>
#define t 100

void adivina()
{
	int numi,num,i;
	srand(time(NULL));
	i=0;
	while(i<3)
	{
		num=rand()%10;
		printf("Desea probar su suerte ingres un numero del 1 al 10:");
		scanf("%i",&numi);
		if(num==numi)
		{
			printf("Felicidades acertaste uuuuuuuuu");
			i=4;
		}
		else
		{
			printf("No joven fallo siga intentando\n");
			printf("Intentos restantes: %i\n",2-i);
			i++;
		}
	}
}

void figo()
{
	int i,a,n,b,c,sum;
	printf("Cuatas veces quiere realizar la suma: ");
	scanf("%i",&n);
	a=1;
	b=2;
	c=0;
	for(i=1;i<=n;i+=1)
	{
		c=c+a;
		printf("%i ",c);
		a=b;
		b=c;
		sum+=c;
	}
	printf("\nLa suma fue %i",sum);
}

void test()
{
	int hora = time(NULL),num,res,i,n,ac=0,fallos=0;
	srand(hora);
	char estado[15],capital[15];
	char estados[t][t]={"Aguascalientes","Baja California","Baja California Sur","Campeche","Coahuila","Colima","Chiapas","Chihuahua","Distrito Federal","Durango","Guanajuato","Guerrero","Hidalgo","Jalisco","Mexico","Michoacan","Morelos","Nayarit","Nuevo Leon","Oaxaca","Puebla","Queretaro","Quintana Roo","San Luis Potosi","Sinaloa","Sonora","Tabasco","Tamaulipas","Tlaxcala","Veracruz","Yucatan","Zacatecas"};
	char capitales[t][t]={"Aguascalientes","Mexicali","La Paz","Campeche","Saltillo","Colima","Tuxtla Gutierrez","Chihuahua","Ciudad de Mexico","Durango","Guanajuato","Chilpancingo","Pachuca","Guadalajara","Toluca","Toluca","Cuernavaca","Tepic","Monterrey","Oaxaca","Puebla","Queretaro","Chetumal","San Luis Potosi","Culiacan","Hermosillo","Villahermosa","Ciudad Victoria","Tlaxcala","Xalapa","Merida","Zacatecas"};
	n = 1;
	printf("Conteste las capitales con estos estados : Aguascalientes, Baja California, Baja California Sur, Campeche, Coahuila, Colima, Chiapas, Chihuahua, Distrito Federal, Durango, Guanajuato, Guerrero, Hidalgo, Jalisco, Mexico, Michoacan, Morelos, Nayarit, Nuevo Leon, Oaxaca, Puebla, Queretaro, Quintana Roo, San Luis Potosi, Sinaloa, Sonora, Tabasco, Tamaulipas, Tlaxcala, Veracruz, Yucatan, Zacatecas");
	for(i=0;i<=n;i++)
	{	
		num = rand()%32;
		printf("\nCual es el Estado donde reside la Capital %s: ",capitales[num]);
		fflush(stdin);gets(estado);
		if(strcmp(estado,estados[num]) == 0)
		{
			printf("Correcto\n");
			ac++;
		}
		else
		{
			printf("Fallaste\n");
			fallos++;
		}
		printf("1)Si\n2)No\nDeseas volver a intentarlo: ");
		scanf("%i",&res);
		if(res == 1)
			n++;
		else
			n--;
	}
	printf("Acertaste: %i\nFallaste: %i",ac,fallos);
}

void amor()
{
	int i,j;
	char amor[4][4]={{'A','X','X','X'},{'X','M','X','X'},{'X','X','O','X'},{'X','X','X','R'}};
	i=0;
	do{
		printf("\n");
		j=0;
		do{
			printf("%c ",amor[i][j]);
			j++;
		}
		while(j<4);
		i++;
	}
	while(i<4);
}

main()
{
	int i,a,n,men;
	char rep;
	do{
	printf("Menu de bucles\n");
	printf("A-Matriz de amor\nT-Test de estados\nD-Loteria\nN-No figo\n");
	fflush(stdin);scanf("%c",&men);
		switch(men)
		{
			case'T':case't':
				test();	
			break;
			case'n':case'N':
				figo();
			break;
			case'd':case'D':
				adivina();	
			break;	
			case'A':case'a':
				amor();	
			break;	
		}
		printf("\nDesea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);	
	}
	while(rep=='S'||rep=='s');
}
