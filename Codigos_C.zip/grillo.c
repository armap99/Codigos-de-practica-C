# include <stdio.h>
# include <stdlib.h>
int main()
{
	int ns,m;
	float t,c;
	printf("");
	printf("Cumero de sonidos del grillo por minuto");
	scanf("%i",&ns);
	t=ns/4+40;
	printf("");
	printf("\nSi decea la temperatura en grados Fahrenheait  escriba 1 \nSi decea la temperatura en grados Centigrados escriba 2\nSi decea salir escriba 3");
    scanf("%i",&m);
    	if (m==1)
			{
    		printf("");
    		printf("\nLa temperatura en grados Fahrenheait es de: %.2f",t);
			}
		if (m==2)
		{
			c=(-32+t)/1.8;
			printf("");
			printf("\nLa temperatura en grados centigrados es de: %.2f",c);
		}
		if (m==3)
		{
			printf("");
			printf("Hasta luego buen dia");
		}


	return 0;
}
