/*Nombre:Luis Armando Prado N��ez
  Programa:Suma de dos matrices menu
  06/10/18
  D.P:Mostrara las matrices a sumar y el resultado de la suma*/
  
  #include<stdio.h>
  #include<stdlib.h>
  #include<conio.h>
  #define t 100
  main()
  {
  	int j,i,fc,a[t][t],b[t][t],c[t][t],hora = time(NULL);
	srand(hora);
  	char rep,men;
  	do{
		printf("Menu de bucles\n");
		printf("F-Suma de matrices con For\nW-Suma de matrices con While\nD-Suma de matrices con Do while\n");
		fflush(stdin);scanf("%c",&men);
		switch(men)
		{
			case'f':case'F':
				printf("Cuantas filas y columnas quieres max 10 ");
			    scanf("%i",&fc);
			    for(i=0;i<fc;i++)
			    {
			        for(j=0;j<fc;j++)
			        {
			            a[i][j]=rand()%20;
			            b[i][j]=rand()%20;
			            c[i][j]=a[i][j]+b[i][j];
			        }
			    }
			    for(i=0;i<fc;i++)
				{
					printf("\n");
					for(j=0;j<fc;j++)
						printf("%i ",a[i][j]);
					printf(" +  ");
					for(j=0;j<fc;j++)
						printf("%i ",b[i][j]);
					printf(" == ");
					for(j=0;j<fc;j++)
						printf("%i ",c[i][j]);
				}
			break;
			case'w':case'W':
				printf("Cuantas filas y columnas quieres max 10 ");
			    scanf("%i",&fc);
			    i=0;
			    while(i<fc)
			    {
			    	j=0;
			        while(j<fc)
			        {
			            a[i][j]=rand()%20;
			            b[i][j]=rand()%20;
			            c[i][j]=a[i][j]+b[i][j];
			            j++;
			        }
			        i++;
			    }
			    i=0;
			    while(i<fc)
				{
					printf("\n");
					j=0;
					while(j<fc)
					{
						printf("%i ",a[i][j]);
						j++;
					}
					printf(" +  ");
					j=0;
					while(j<fc)
					{
						printf("%i ",b[i][j]);
						j++;
					}
					printf(" == ");
					j=0;
					while(j<fc)
					{
						printf("%i ",c[i][j]);
						j++;
					}
					i++;
				}
			break;
			case'd':case'D':
				printf("Cuantas filas y columnas quieres max 10 ");
			    scanf("%i",&fc);
			    i=0;
			    do{
			    	j=0;
			        do{
			            a[i][j]=rand()%20;
			            b[i][j]=rand()%20;
			            c[i][j]=a[i][j]+b[i][j];
			            j++;
			        }
			        while(j<fc);
			        i++;
			    }
			    while(i<fc);
			    i=0;
				do{
					printf("\n");
					j=0;
					do{
						printf("%i ",a[i][j]);
						j++;
					}
					while(j<fc);
					printf(" +  ");
					j=0;
					do{
						printf("%i ",b[i][j]);
						j++;
					}
					while(j<fc);
					printf(" == ");
					j=0;
					do{
						printf("%i ",c[i][j]);
						j++;
					}
					while(j<fc);
					i++;
				}
				while(i<fc);
			break;
		}
		printf("Desea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
		system("cls");
	}
	while(rep=='S'||rep=='s');
  }
