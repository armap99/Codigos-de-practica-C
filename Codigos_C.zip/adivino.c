/*Nombre:Luis Armando Prado N��ez
  Programa: Adivina
  10/10/18
  D.P:Se llama la funcion de adivina en el cual se ingresara un numero y te dira si lo adivinaste*/

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>  
#include<time.h> 

void adivina()
{
	int numi,num,i;
	srand(time(NULL));
	i=0;
	while(i<3)
	{
		num=rand()%10;
		printf("Desea probar su suerte ingres un numero del 1 al 10:");
		scanf("%i",&numi);
		if(num==numi)
		{
			printf("Felicidades acertaste uuuuuuuuu");
			i=4;
		}
		else
		{
			printf("No joven fallo siga intentando\n");
			printf("Intentos restantes: %i\n",2-i);
			i++;
		}
	}
}
main()
{
	int rep;
	do{
		adivina();
		printf("\nDesea repetir el test: 1-SI");
		scanf("%i",&rep);
		system("cls");
		getch();
	}
	while(rep==1);
}
