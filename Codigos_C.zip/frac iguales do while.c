/*Nombre:Luis Armando Prado Nu�ez
  Problema:Suma de fracciones igiales a uno
  05/09/18
  D.P:Muestra en pantalla la suma de fracciomes igiales a uno*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int i,n;
	float a;
	char rep;
	do{
		printf("Cuantas veces quiere aumentar el denominador y numerador? ");
		scanf("%i",&n);
		a=0;
		i=1;
		do{
			printf("%i/%i ",i,i);
			a+=1;
			i+=1;
		}
		while(i<=n);
		printf("\nEl resultado de la suma es: %f",a);
		printf("\nDesea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
	}
	while(rep=='S'||rep=='s');
}  
