/*Nombre:Luis Armando Prado N��ez
  Programa:Hacer una piramide de n numeros con for
  21/09/18
  D.P:Mostrar en pantalla los numeros deceados acomodados en forma de piramide*/
#include<stdio.h>
#include<conio.h>
main()
{
	int n,j,i;
	char rep;
	do{
		printf("Hasta que numero quiere realizar la figura: ");
		scanf("%i",&n);
		for(i=1;i<=n;i++)
		{
			printf("\n");
			for(j=1;j<=n;j++)
			{
				if(j+i>n)
				{
					printf(" %i",j+i-n);
				}
				else
					printf(" ");
			}
		}
		printf("\nDesea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);
		system("cls");
	}
	while(rep=='S'||rep=='s');
}
