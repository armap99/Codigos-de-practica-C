/*Nombre:Luis Armando Prado N��ez
  Programa:Mostrar en una diagonal 4X4 amor con do-while pero en una funcion
  06/10/18
  D.P:Mostrara una matriz 4X4 que en su diagonal diga amor  */

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#define t 10
void amor();

main()
{
	int rep;
	do{
		printf("Invocacion de amor\n");
		amor();
		printf("\nDesea repetir el test: 1-SI");
		scanf("%i",&rep);
		system("cls");
		getch();
	}
	while(rep==1);
}

void amor()
{
	int i,j;
	char amor[4][4]={{'A','X','X','X'},{'X','M','X','X'},{'X','X','O','X'},{'X','X','X','R'}};
	i=0;
	do{
		printf("\n");
		j=0;
		do{
			printf("%c ",amor[i][j]);
			j++;
		}
		while(j<4);
		i++;
	}
	while(i<4);
}
