/*Nombre:Luis Armando Prado N��ez
  Problema:Factorial de un munero con for y retorno y sin parametro
  17/10/18
  D.P:Se ingresara el numero que se quiera realizar el facorial y se mostrara en pantalla*/
  
#include<stdio.h>
#include<conio.h>
long int t;
int act()
{
	int i,n;
	printf("Que factorial quiere realizar: ");
	scanf("%i",&n);
	t=1;
	for(i=n;i!=0;i-=1)
	{
		printf("%i*",i);
		t*=i;
	}
	return t;
}

main()
{
	int rep;
	do{
		act();
		printf("\nEl factorial es: %li",t);	
		printf("\nDesea repetir el factorial: 1-SI");
		scanf("%i",&rep);
		system("cls");
		getch();
	}
	while(rep==1);
}
