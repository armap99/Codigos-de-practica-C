/*Nombre:Luis Armando Prado N��ez
  Problema:Cuantas cifras tiene un numero con while
  12/09/18
  D.P:Se ingresara un numero y te mostrara la pantalla cuantos digitos tiene*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int n,i,sob;
	printf("Intriduzca un numero: ");
	scanf("%i",&n);
	sob=0;
	i=n;
	do{
		sob+=1;
		i/=10;
	}
	while(i>0);
	printf("Tiene %i digitos",sob);
	getch();
}
