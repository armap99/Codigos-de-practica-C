/*Nombre:Luis Armando Prado N��ez
  Programa:Dibujo de un barco con do-while
  21/09/18
  D.P:Mostrar en pantalla un barco creado por ciclos*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int i,j;
	i=1;
	do{
		printf("\n");
		j=1;
		do{
			printf("  X");
			j++;
		}
		while(j<=i);
		i++;
	}
	while(i<=4);
	i=1;
	do{
		printf("\n");
		j=1;
		do{
			printf("  X");
			j++;
		}
		while(j<=2);
		i++;
	}
	while(i<=2);
	i=1;
	do{
		printf("\n");
		j=1;
		do{
			if(i+j>10||i==4&&j<=2||i==3&&j==1)
				printf("  ");
			else
				printf("X ");
			j++;
		}
		while(j<=8);
		i++;
	}
	while(i<=4);
	i=1;
	do{
		printf("\n");
		j=1;
		do{
			printf("~~");
			j++;
		}
		while(j<=8);
		i++;
	}
	while(i<=2);
}
