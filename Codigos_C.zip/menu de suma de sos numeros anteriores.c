/*Nombre:Luis Armando Prado Nu�ez
  Problema:Menu de serie de impaeres y su suma con bucles
  05/09/18
  D.P:Muestra en pantalla el menu de las serie de numeros inparaes y la suma hasta un munero introducido por teclado*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int i,a,b,c,n,men;
	char rep;
	do{
	printf("Menu de bucles\n");
	printf("F-For\nW-While\nD-Do while\n");
	fflush(stdin);scanf("%c",&men);
		switch(men)
		{
			case'f':case'F':
				printf("Cuatas veces quiere realizar la suma: ");
				scanf("%i",&n);
				a=1;
				b=0;
				c=0;
				for(i=1;i<=n;i+=2)
				{
					a+=b;
					b+=a;
					printf("%i %i ",a,b);
					c=a+c+b;
				}
				printf("La suma total es: %i\n",c);
			break;
			case'w':case'W':
				printf("Cuantas veces quiere realizar la suma: ");
				scanf("%i",&n);
				i=1;
				a=1;
				b=0;
				c=0;
				while(i<=n)
				{
					i+=2;
					a+=b;
					b+=a;
					printf("%i %i ",a,b);
					c=a+c+b;
				}
				printf("La suma total es: %i\n",c);
			break;
			case'd':case'D':
				printf("Cuantas veces quiere realizar la suma: ");
				scanf("%i",&n);
				i=1;
				a=1;
				b=0;
				c=0;
				do{
					i+=2;
					a+=b;
					b+=a;
					printf("%i %i ",a,b);
					c=a+c+b;
				}
				while(i<=n);
				printf("La suma total es: %i\n",c);
			break;	
		}
		printf("Desea hacer de nuevo el programa\nS=SI \nN=NO\n");
		fflush(stdin);scanf("%c",&rep);	
	}
	while(rep=='S'||rep=='s');
}


