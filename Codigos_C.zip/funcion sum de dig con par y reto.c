/*Nombre:Luis Armando Prado N��ez
  Problema:Cuantos digitos y suma de los digitos 
  17/10/18
  D.P:Se ingresara el numero se sumaran los digitos y muestra cuantos tiene*/
  
#include<stdio.h>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
#define p printf
#define s scanf
int i,sum,op,num,au,num1,j;

int cuantos(int num){
	i=1;
	num1=num;
	while((num1/10)>0)
	{
	    num1=num1/10;
	    i++;
	}
	j=i;}
        
int suma(int num){
    au=pow(10,j-1);
    sum=num/au;
    while(j-1>1){ 
    	j=j-1;
    	au=pow(10,j-1);
		sum=sum+(num/au)%10; 
		}
	sum=sum+(num)%10;
	}

main()
{
	do{
		p("\nIngrese un numero entero: ");
		s("%i",&num);
		cuantos(num);
		suma(num);
		p("Tiene %i digitos\n",i);
		p("La suma de los digitos es :%i\n",sum);
		p("\nRepetir: 1-SI\n ");
		s("%i",&op);
	}while(op==1);
}
