/*Nombre:Luis Armando Prado N��ez
  Programa:Suma de listas do-while 
  06/10/18
  D.P: Se pediran dos listas de n tama�os y se sumaran y se mostraran en pantalla*/

#include<stdio.h>
#include <conio.h>
#define t 100
main()
{
	int n,pri[t],seg[t],suma[t],i,j;
  	char rep;
	do{
		printf("De que tama�o son las listas? ");
    	scanf("%i",&n);
    	i=0;
	    do{
	      printf("Ingrese %i valor de la primera lista : ",i+1);
	      scanf("%i",&pri[i]);
	      printf("Ingrese %i valor de la segunda lista :",i+1);
	      scanf("%i",&seg[i]);
	      i++;
	    }
	    while(i<n);
	    j=0;
	  	do{
	    	suma[j]=pri[j]+seg[j];
	    	printf("%i ",suma[j]);
	    	j++;
	  	}
	  	while(j<n);
	  	printf("  ==  ");
	  	i=0;
		do{
		  	printf("%i ",pri[i]);
		  	i++;
		}
		while(i<n);
		printf(" + ");
		i=0;
		do{
		  	printf("%i ",seg[i]);
		  	i++;
		}
		while(i<n);
	    printf("\nDesea hacer de nuevo el programa\nS=SI \nN=NO\n");
	  	fflush(stdin);scanf("%c",&rep);
	}
	while(rep=='S'||rep=='s');
  	getch();
}
