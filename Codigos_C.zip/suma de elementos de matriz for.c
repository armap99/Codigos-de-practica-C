/*Nombre:Luis Armando Prado N��ez
  Programa:Suma de datos de una matriz for 
  03/10/18
  D.P:Mostrara la matriz introducuda y la suma de sus elementos */
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#define t 10
#include<time.h>
main()
{
    int i,j,matriz[t][t],fc,rep,sumd,numi;
    srand(time(NULL));
    do
    {
        printf("Cuantas filas y columnas quieres max 10 ");
        scanf("%i",&fc);
        for(i=0;i<fc;i++)
        {
        	printf("\n");
            for(j=0;j<fc;j++)
            {
                numi=rand()%10;
                matriz[i][j]=numi;
                sumd+=matriz[i][j];
                printf("%i ",matriz[i][j]);
            }
        }
		printf("\nLa suma de todos los datos es %i",sumd);
        printf("\nDeseas repetir el programa? 1=si ");
        scanf("%i",&rep);
    }while(rep==1);
    getch();
}
