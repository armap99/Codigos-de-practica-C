#include<string.h>
#include<stdio.h>

int main() {

char nombre[5][20];
char apellido[5][20];
char nombreCompleto[5][40];
int i,opc;

do{
    printf("**************************************************************************************************************\n");
    printf("Menu String\n [1] Ingresar nombres\n [2] Ingresar apellidos\n [3] Nombres Completos\n [4] Salir \n");
    scanf("%d",&opc);
    switch (opc)
    {
    case 1:
        for(i=0;i<5;i++)
        {
            printf("Ingresa el nombre de la persona %d: \n",i+1);
            scanf("%s",nombre[i]);
        }
        break;
    case 2:
        for(i=0;i<5;i++)
        {
            printf("Ingresa el apellido de la persona %d: \n",i+1);
            scanf("%s",apellido[i]);
        }
        break;
    case 3:
        for(i=0;i<5;i++)
        {
        strcpy(nombreCompleto[i],nombre[i]);
        strcat(nombreCompleto[i]," ");
        strcat(nombreCompleto[i],apellido[i]);
        printf("Nombre : %s   Apellido : %s  Nombre Completo : %s \n",nombre[i],apellido[i],nombreCompleto[i]);
        }

        break;

    case 4:
        printf("Adios");
        break;

    default:
        printf("Opcion no valida");
        break;
}


}while(opc!=4);
return 0;
}
