/*Nombre:Luis Armando Prado N��ez 
  Programa:Estructuras de alumnos
  Fecha:24/10/18
  D.P:Se pediran los nombres de un alumnos y se guardaran en una estrsuctura y despues los promedios */
  
#include<stdio.h>
#include <conio.h>
main()
{
	int i,n,j,cal;
	char rep;
	float temp=0;
	struct{
		char nom[50];
		float prom;
	}alum[100];
	do{
		printf("Cuantos alumnos va a ingresar: ");
		scanf("%i",&n);
		for(i=0;i<n;i++)
		{
			printf("Ingrese el nombre :");
			fflush(stdin);gets(alum[i].nom);
			for(j=0;j<6;j++)
			{
				printf("\nIngrese %i calificacion: ",j);
				scanf("%i",&cal);
				temp+=cal;
			}
			temp=temp/6;
			alum[i].prom=temp;
		}
		for(i=0;i<n;i++)
		{
			printf("Nombre : %s\n",alum[i].nom);
			printf("Promedio : %f\n",alum[i].prom);
			printf("\n");
		}
		printf("\nDeseas volver a corre el programa?\nS=si\nN=no");
		fflush(stdin);scanf("%c",&rep);
	}
	while(rep=='S' || rep=='s');
}
