/*Nombre:Luis Armando Prado N��ez
  Programa: Test de capitales for con funcion 
  10/10/18
  D.P:Preguntar que capital le pertenece a cada estado y decir si esta bien pero todo en una funcion y despues siendo llamado*/

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>  
#include<time.h> 
#include<string.h>
void test();
#define t 100

main()
{
	int rep;
	do{
		test();
		printf("\nDesea repetir el test: 1-SI");
		scanf("%i",&rep);
		system("cls");
		getch();
	}
	while(rep==1);
}

void test()
{
	int hora = time(NULL),num,res,i,n,ac=0,fallos=0;
	srand(hora);
	char estado[15],capital[15];
	char estados[t][t]={"Aguascalientes","Baja California","Baja California Sur","Campeche","Coahuila","Colima","Chiapas","Chihuahua","Distrito Federal","Durango","Guanajuato","Guerrero","Hidalgo","Jalisco","Mexico","Michoacan","Morelos","Nayarit","Nuevo Leon","Oaxaca","Puebla","Queretaro","Quintana Roo","San Luis Potosi","Sinaloa","Sonora","Tabasco","Tamaulipas","Tlaxcala","Veracruz","Yucatan","Zacatecas"};
	char capitales[t][t]={"Aguascalientes","Mexicali","La Paz","Campeche","Saltillo","Colima","Tuxtla Gutierrez","Chihuahua","Ciudad de Mexico","Durango","Guanajuato","Chilpancingo","Pachuca","Guadalajara","Toluca","Toluca","Cuernavaca","Tepic","Monterrey","Oaxaca","Puebla","Queretaro","Chetumal","San Luis Potosi","Culiacan","Hermosillo","Villahermosa","Ciudad Victoria","Tlaxcala","Xalapa","Merida","Zacatecas"};
	n = 1;
	printf("Conteste las capitales con estos estados : Aguascalientes, Baja California, Baja California Sur, Campeche, Coahuila, Colima, Chiapas, Chihuahua, Distrito Federal, Durango, Guanajuato, Guerrero, Hidalgo, Jalisco, Mexico, Michoacan, Morelos, Nayarit, Nuevo Leon, Oaxaca, Puebla, Queretaro, Quintana Roo, San Luis Potosi, Sinaloa, Sonora, Tabasco, Tamaulipas, Tlaxcala, Veracruz, Yucatan, Zacatecas");
	for(i=0;i<=n;i++)
	{	
		num = rand()%32;
		printf("\nCual es el Estado donde reside la Capital %s: ",capitales[num]);
		fflush(stdin);gets(estado);
		if(strcmp(estado,estados[num]) == 0)
		{
			printf("Correcto\n");
			ac++;
		}
		else
		{
			printf("Fallaste\n");
			fallos++;
		}
		printf("1)Si\n2)No\nDeseas volver a intentarlo: ");
		scanf("%i",&res);
		if(res == 1)
			n++;
		else
			n--;
	}
	printf("Acertaste: %i\nFallaste: %i",ac,fallos);
}
