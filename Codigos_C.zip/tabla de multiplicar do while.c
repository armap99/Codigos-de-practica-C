/*Nombre:Luis Armando Prado N��ez
  Problema:Tabla de multiplicar con  do while
  12/09/18
  D.P:Se ingresara el numero del cual se quiere realizar la tabla de multiplicar*/
  
#include<stdio.h>
#include<conio.h>
main()
{
	int n,res,i;
	printf("Que tabla de multiblicar quiere realizar? ");
	scanf("%i",&n);
	res=0;
	i=1;
	do{
		res=n*i;
		printf("%i*%i=%i\n",n,i,res);
		i+=1;
	}
	while(i<=10);
	getch();
}
